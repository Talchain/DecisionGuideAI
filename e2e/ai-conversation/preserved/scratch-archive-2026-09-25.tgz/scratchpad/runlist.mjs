import fs from 'fs'
import { spawnSync } from 'child_process'
const ROOT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-ae0a1196dc98bd4dc'
const files = fs.readFileSync(process.argv[2], 'utf8').split('\n').map((s) => s.trim()).filter(Boolean)
const res = spawnSync('npx', ['vitest', 'run', ...files], {
  cwd: ROOT,
  env: {
    ...process.env,
    VITE_SUPABASE_URL: 'http://localhost',
    VITE_SUPABASE_ANON_KEY: 'test',
    NODE_OPTIONS: '--max-old-space-size=6144',
  },
  encoding: 'utf8',
  maxBuffer: 1024 * 1024 * 1024,
  timeout: 1800000,
})
fs.writeFileSync(process.argv[3], (res.stdout ?? '') + (res.stderr ?? ''))
console.log(`vitest exit=${res.status} signal=${res.signal}`)
process.exit(res.status ?? 1)
