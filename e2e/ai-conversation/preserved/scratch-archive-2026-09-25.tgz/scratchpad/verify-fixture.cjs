const crypto = require('node:crypto');
for (const p of process.argv.slice(2)) {
  const f = JSON.parse(require('node:fs').readFileSync(p, 'utf8'));
  const { _provenance, ...body } = f;
  const h = crypto.createHash('sha256').update(JSON.stringify(body), 'utf8').digest('hex');
  console.log(p.split('/').pop(), h === _provenance.route_body_sha256 ? 'OK' : 'MISMATCH', h);
}
