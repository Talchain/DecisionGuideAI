const m = await import('@talchain/schemas')
const s = m.OlumiResponseSchema
for (const [k, v] of Object.entries(s.shape)) console.log(k, v.isOptional() ? 'optional' : 'REQUIRED')
