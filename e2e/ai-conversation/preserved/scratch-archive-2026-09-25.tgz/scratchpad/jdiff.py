import json, sys


def walk(a, b, p=''):
    if type(a) != type(b):
        print(f"{p}: TYPE {type(a).__name__} -> {type(b).__name__}")
        return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a:
                print(f"{p}.{k}: ADDED {json.dumps(b[k])[:200]}")
            elif k not in b:
                print(f"{p}.{k}: REMOVED")
            else:
                walk(a[k], b[k], f"{p}.{k}")
    elif isinstance(a, list):
        if len(a) != len(b):
            print(f"{p}: LEN {len(a)} -> {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            walk(x, y, f"{p}[{i}]")
    elif a != b:
        print(f"{p}: {json.dumps(a)[:200]} -> {json.dumps(b)[:200]}")


a = json.load(open(sys.argv[1]))
b = json.load(open(sys.argv[2]))
walk(a, b)
