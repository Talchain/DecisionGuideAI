const { PNG } = require('pngjs'); const fs = require('fs'); const dir = process.argv[2]
for (const vp of ['1280x800', '1440x900']) {
  const f = PNG.sync.read(fs.readFileSync(`${dir}/14-withheld-pills-fix-${vp}.png`))
  const s = PNG.sync.read(fs.readFileSync(`${dir}/14-withheld-pills-staging-${vp}.png`))
  const rows = []
  for (let k = 1; k <= 14; k++) {
    const yf = f.height - k, ys = s.height - k; let n = 0, max = 0
    for (let x = 0; x < f.width; x++) { const i = (yf * f.width + x) * 4, j = (ys * s.width + x) * 4; const d = Math.max(Math.abs(f.data[i]-s.data[j]), Math.abs(f.data[i+1]-s.data[j+1]), Math.abs(f.data[i+2]-s.data[j+2])); if (d) n++; if (d > max) max = d }
    rows.push(`-${k}:${n}px/δ${max}`)
  }
  // Also: fix bottom band (rows 315..end) vs staging rows shifted by 63.
  let n = 0, max = 0
  for (let y = 315; y < f.height; y++) for (let x = 0; x < f.width; x++) { const i = (y * f.width + x) * 4, j = ((y + 63) * s.width + x) * 4; const d = Math.max(Math.abs(f.data[i]-s.data[j]), Math.abs(f.data[i+1]-s.data[j+1]), Math.abs(f.data[i+2]-s.data[j+2])); if (d) n++; if (d > max) max = d }
  console.log(vp, rows.join(' '), `| fix rows 315..${f.height-1} vs staging +63: ${n}px δmax ${max}`)
}
