const { PNG } = require('pngjs'); const pixelmatch = require('pixelmatch').default ?? require('pixelmatch'); const fs = require('fs')
const dir = process.argv[2]
const crop = (img, y0, h) => { const out = new PNG({ width: img.width, height: h }); PNG.bitblt(img, out, 0, y0, img.width, h, 0, 0); return out }
const exact = (a, b) => { let n = 0; for (let i = 0; i < a.data.length; i += 4) if (a.data[i] !== b.data[i] || a.data[i+1] !== b.data[i+1] || a.data[i+2] !== b.data[i+2] || a.data[i+3] !== b.data[i+3]) n++; return n }
for (const vp of ['1280x800', '1440x900']) {
  const f = PNG.sync.read(fs.readFileSync(`${dir}/14-withheld-pills-fix-${vp}.png`))
  const s = PNG.sync.read(fs.readFileSync(`${dir}/14-withheld-pills-staging-${vp}.png`))
  const res = { vp, fix: [f.width, f.height], staging: [s.width, s.height] }
  // Find the first row (from the top) where they differ.
  let firstDiff = -1
  for (let y = 0; y < Math.min(f.height, s.height) && firstDiff < 0; y++) {
    for (let x = 0; x < f.width; x++) { const i = (y * f.width + x) * 4; if (f.data[i] !== s.data[i] || f.data[i+1] !== s.data[i+1] || f.data[i+2] !== s.data[i+2]) { firstDiff = y; break } }
  }
  res.firstDifferingRowFromTop = firstDiff
  // Bottom band: the same number of rows from the bottom of each.
  let bottomSame = 0
  for (let k = 1; k <= Math.min(f.height, s.height); k++) {
    const yf = f.height - k, ys = s.height - k; let same = true
    for (let x = 0; x < f.width; x++) { const i = (yf * f.width + x) * 4, j = (ys * s.width + x) * 4; if (f.data[i] !== s.data[j] || f.data[i+1] !== s.data[j+1] || f.data[i+2] !== s.data[j+2]) { same = false; break } }
    if (!same) break; bottomSame = k
  }
  res.identicalRowsFromBottom = bottomSame
  const top = firstDiff < 0 ? Math.min(f.height, s.height) : firstDiff
  res.topBandExactDiffPx = exact(crop(f, 0, top), crop(s, 0, top))
  res.extraStagingRows = s.height - f.height
  console.log(JSON.stringify(res))
}
