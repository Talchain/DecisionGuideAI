/**
 * SuggestedChips — stagger-animated action chips after AI messages.
 *
 * Each chip fades in + slides up with 70ms delay between.
 * 0-3 chips (ruled doctrine D-K, closed 15 Jul: render up to 3 when CEE
 * offers 3; render none when CEE offers none — never fabricate a filler
 * chip; labels render verbatim as sent by CEE). Chip base: bg-panel, border
 * border-panel-border, hover:bg-panel-hover. Role metadata preserved via
 * data-chip-role and aria-label for styling/accessibility.
 *
 * In-flight behaviour: when isThinking=true all chips in this turn are disabled
 * (greyed out, not clickable). Re-enabled if request fails.
 * Historical chips (isHistorical=true) are not rendered.
 *
 * Run gate: when the host passes `runGate` and it is closed, a Run chip renders
 * disabled with the gate's own sentence beneath the row (see `RunChipGate`).
 *
 * Click failures show a brief inline error that auto-dismisses after 5s.
 */

import { useState, useEffect, useId } from 'react'
import { typography } from '../../../styles/typography'
import { isV5Eligible } from '../../../v5/eligibility'
import { logV5StateEvent } from '../../../v5/debugLog'
import { isAiPanelV2Enabled } from '../../../flags'
import {
  admitsRunAffordance,
  useAnalysisMayRun,
  useAnalysisStatus,
} from '../../hooks/useAnalysisReady'
import { useCanvasStore } from '../../store'
import { useGuidanceStore } from '../../stores/guidanceStore'
import { type FreshnessDisplaySemantic } from '../../store/analysisFreshness'
import { useAnalysisTrust } from '../../hooks/useAnalysisTrust'
import { isChipRenderable } from '../chipDispatch'
import { analysisHeldOn } from '../../utils/analysisHeldOnInjectedModel'
import { V5_ENABLED_ACTIONS } from '../chipActionVocabulary'
import { CHIP_CLASS } from '../../../v5/blocks/chipClass'
import type { ActionChip } from '../types'

// Actions that V5 CEE handles end-to-end. Chips whose action_type is set and
// not in this set are filtered out when V5 is active. On V4 the set is
// unused — all chips pass through unchanged.
//
// DERIVED, not listed (ROADMAP 2.668). This used to be seven hand-written
// strings, and the three missing ones were CEE's entire graph-mutation
// vocabulary — so every propose-confirm consent chip CEE emitted was deleted
// here on arrival. `chipActionVocabulary` now derives the set from the wire
// send gate + the dispatch map; read that module for the full account.
// Re-exported from here because this is where importers have always found it.
export { V5_ENABLED_ACTIONS }

// Chips whose action_type is in this set require analysis readiness
// (ceeAnalysisReady.status === 'ready') before they can render. Without it,
// a click would land on a run_analysis turn that the safety net at
// useConversation.ts:1687 demotes to conversation — visible to the user as
// a chip that promises action and delivers chat.
const READINESS_GATED_ACTIONS = new Set<string>(['run_analysis'])

/**
 * Run-analysis affordance detection. `action_type` is the primary key;
 * the fallback regex catches V4-legacy or prompt-only chips where the
 * `action_type` field is absent. Tolerant of "Run analysis", "Rerun
 * analysis", "Run the analysis", "Rerun the analysis", with or without a
 * trailing period. Conservative enough to NOT match conversational chips
 * like "Explain the analysis" or "What was the analysis?".
 */
const RUN_ANALYSIS_RE = /^(?:run|rerun)\s+(?:the\s+)?analysis\.?$/i

function normForMatch(s: string | undefined): string {
  return (s ?? '').trim()
}

// Exported so the chip row's host (`ConversationPanel.handleChipClick`) routes
// a Run chip by the SAME detector that decides it is gated here: one predicate,
// never a second copy to drift.
export function isRunAnalysisAffordance(chip: ActionChip): boolean {
  if (chip.action_type === 'run_analysis') return true
  return (
    RUN_ANALYSIS_RE.test(normForMatch(chip.label)) ||
    RUN_ANALYSIS_RE.test(normForMatch(chip.message)) ||
    RUN_ANALYSIS_RE.test(normForMatch(chip.prompt))
  )
}

/**
 * Product rule for the run-analysis affordance under aiPanelV2:
 *   - no analysis exists            → keep chip as-is ("Run analysis")
 *   - confirmed-current analysis    → suppress chip entirely
 *   - stale / cannot-confirm        → relabel chip to "Rerun" (may bypass the V5
 *                                     readiness gate — a prior analysis exists and
 *                                     a rerun re-derives inputs from the graph)
 *   - complete, NO freshness verdict→ keep ("Run analysis"), SUBJECT to the gate
 *
 * Two positive-signal branches:
 *   - SUPPRESS requires a CONFIRMED-CURRENT verdict (semantic === 'current').
 *   - the readiness-gate-bypassing 'relabel-rerun' requires a REAL freshness
 *     verdict ('changed' / 'cannot_confirm'), which implies a prior analysis that
 *     a rerun can re-derive from the current graph.
 * A completed analysis with NO freshness verdict ('none') gets neither: it is not
 * confirmed current (so not suppressed — matching useStageAwarePlaceholder, which
 * treats it as not-"latest"), but it has nothing rerunnable to justify bypassing
 * the readiness gate. Relabelling it to "Rerun" would let a run_analysis chip
 * survive the gate even when ceeAnalysisReady is missing, and a click then falls
 * back to a conversation turn ("promises action, delivers chat"). So it stays a
 * plain 'keep' chip, shown only when the readiness gate is satisfied.
 *
 * This replaces the legacy graph-hash stale flag (deleted 2026-07-16), whose production input
 * `_internal.graphHash` is never written, so it never fired.
 */
type RunAnalysisPolish = 'suppress' | 'relabel-rerun' | 'keep'

function decideRunAnalysisPolish(
  resultsComplete: boolean,
  freshnessSemantic: FreshnessDisplaySemantic,
): RunAnalysisPolish {
  if (!resultsComplete) return 'keep'                     // no analysis yet
  if (freshnessSemantic === 'current') return 'suppress'  // confirmed-current owns the action
  if (freshnessSemantic === 'changed' || freshnessSemantic === 'cannot_confirm') {
    return 'relabel-rerun'  // real verdict: prior analysis exists → offer rerun (gate-bypassing)
  }
  return 'keep'  // 'none': complete but no verdict → not current, but no rerunnable
                 // analysis to justify a gate bypass; the readiness gate decides visibility
}

/**
 * The host's run-gate verdict, handed down so a Run chip can SHOW the gate
 * rather than discover it on click.
 *
 * `allowed` and `reason` are the values the host's own Analyse control already
 * uses (`ConversationPanel`: `runGateResult.allowed && !isAnalysisRunning` and
 * `runBlockedReason`). This component never computes a gate of its own and never
 * authors copy for one: `reason` is rendered verbatim, and when it is absent the
 * chip is simply disabled.
 */
export interface RunChipGate {
  allowed: boolean
  reason?: string
}

interface SuggestedChipsProps {
  chips: ActionChip[]
  onChipClick: (chip: ActionChip) => Promise<void>
  /** When true, all chips are disabled while a response is pending */
  isThinking?: boolean
  /**
   * When true, this turn's chips are historical (a newer response has arrived).
   * Historical chips are not rendered.
   */
  isHistorical?: boolean
  /**
   * The host's run gate. Absent (headless mounts) ⇒ the previous behaviour,
   * unchanged: a Run chip is live and its click goes to the guidance store's
   * registered `_runAnalysis` when there is one. Present ⇒ the host owns the
   * run decision: a closed gate disables every Run chip (non-run chips stay
   * live) and an open one sends the click to `onChipClick`, where the host runs
   * it through the same gate.
   */
  runGate?: RunChipGate
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function SuggestedChips({
  chips,
  onChipClick,
  isThinking = false,
  isHistorical = false,
  runGate,
}: SuggestedChipsProps) {
  // All hooks are declared before any conditional return so that the hook
  // count is stable across renders. Downstream conditions (isHistorical,
  // visible.length === 0) use early-return AFTER the hook prelude — this
  // is the rules-of-hooks contract. Readiness transitions
  // (ready → missing, ready → not_ready) flip `visible` emptiness on the
  // fly; hoisting the two subscribers keeps React's dispatcher aligned.
  const [chipError, setChipError] = useState<string | null>(null)
  const analysisStatus = useAnalysisStatus()
  // CEE's own admission verdict for this turn. `undefined` on a pre-`may_run`
  // CEE, which `admitsRunAffordance` reads as "fall back to `status`".
  const analysisMayRun = useAnalysisMayRun()
  // aiPanelV2 polish: once an analysis has been RUN (results exist), the
  // canonical place for re-running it is the Analysis/readiness panel.
  // Decision is via `decideRunAnalysisPolish` (product rule, see helper above):
  // no analysis → keep; confirmed-current → suppress; stale/cannot-confirm →
  // "Rerun" (gate-bypassing); complete-but-no-verdict → keep (gate decides).
  // `freshnessSemantic` is the composed trust semantic (useAnalysisTrust),
  // NOT the graph-hash stale path deleted on 2026-07-16. The orphan fold
  // means a recovered-session result with no verdict reads cannot-confirm
  // here too, so the chip relabels to "Rerun" in step with the strip.
  const freshnessSemantic = useAnalysisTrust().semantic
  const resultsComplete = useCanvasStore((s) => s.results?.status === 'complete')
  // ⭐ PoC DOMAIN 5 — the chip reads the SAME held-model authority the Analyse
  // control reads (`canRunAnalysis` rung 2.5), so the two cannot disagree ABOUT
  // THE HOLD. Non-null ⇒ the canvas holds a client-injected graph that CEE never
  // received, so a run would answer about a different model.
  //
  // ⚠ AND THAT IS THE WHOLE OF THE CLAIM for THIS filter. An earlier draft said
  // the two "cannot disagree about whether THIS run is possible", which is FALSE
  // for the hold alone on at least three reachable states — graph-health errors,
  // a streamed draft still settling, and `readiness.can_run_analysis: false`.
  // The gate has six rungs; this filter shares one of them.
  //
  // ⭐ THE FULLER FIX — ONE PROP — IS NOW TAKEN (`runGate`). `ConversationPanel`
  // hands down the verdict its own Analyse control uses (`runGateResult.allowed
  // && !isAnalysisRunning` — every rung of the gate) and the sentence it
  // already shows for it (`runBlockedReason`). With the gate closed, a Run chip
  // renders DISABLED with that sentence as its accessible description, instead
  // of looking live and refusing only after the click. With it open, the click
  // goes to the host's `handleChipClick`, which runs it through the same gate.
  // Filtering is untouched: a gated chip is shown and disabled, never hidden, so
  // the user sees the affordance AND why it is not available yet. Hosts that
  // pass no gate (headless mounts) keep the previous path exactly.
  //
  // (Related, same neighbourhood: the wire already carries `usable_for_chips` —
  // CEE's own chip-safety statement — surfaced at `analysisStateSelector` and
  // read today only by the coherence DIAGNOSTIC, never by this surface.)
  const heldOn = useCanvasStore((s) => analysisHeldOn(s))
  // Declared in the hook prelude (rules of hooks): the id the gate's sentence
  // carries, so each gated Run chip can name it in `aria-describedby`.
  const runGateReasonId = useId()
  const aiPanelV2On = isAiPanelV2Enabled()
  useEffect(() => {
    if (!chipError) return
    const timer = setTimeout(() => setChipError(null), 5_000)
    return () => clearTimeout(timer)
  }, [chipError])

  // Historical chips removed entirely — no false affordance.
  if (isHistorical) return null

  // Evaluate V5 eligibility per-render so test env overrides (vi.stubEnv)
  // are picked up correctly. import.meta.env is Vite-inlined at build time,
  // but the check is cheap and correctness matters more here.
  const v5Active = isV5Eligible({ flag: import.meta.env?.VITE_ENABLE_V5_ORCHESTRATOR }).eligible

  // Compute the run-analysis product state ONCE, then both the V5
  // readiness gate (below) AND the polish-map step downstream branch on
  // the same value. Keeping a single source of truth prevents a future
  // change to either branch from re-introducing "filtered before
  // relabel" behaviour.
  const runAnalysisPolish: RunAnalysisPolish = aiPanelV2On
    ? decideRunAnalysisPolish(resultsComplete, freshnessSemantic)
    : 'keep'

  // Filter rule (V5 active):
  //   action_type === 'run_analysis' → gated by `admitsRunAffordance`, i.e.
  //                                    analysisStatus === 'ready' OR CEE's own
  //                                    may_run === true,
  //                                    EXCEPT when aiPanelV2 will relabel to
  //                                    "Rerun" (stale/cannot-confirm), in which
  //                                    case the chip must survive the gate so the
  //                                    polish can apply.
  //   action_type absent              → pass through (conversational)
  //   action_type in V5_ENABLED_ACTIONS but NOT readiness-gated → pass through
  //   action_type present but unknown → hide (treat as potentially executable
  //                                     with an unsatisfied gate)
  // On V4 (not V5-active), all chips pass through unchanged.
  // ⭐ THE HELD-MODEL GATE (PoC domain 5) — a SEPARATE filter over `chips`,
  // never a conjunct of the readiness predicate.
  //
  //  · ⚠ IT MUST NOT LIVE INSIDE THE READINESS GATE BELOW. That predicate has a
  //    deliberate early `return true` for `runAnalysisPolish === 'relabel-rerun'`,
  //    and an early `return true` for chips with no `action_type` — so a hold
  //    written as one more clause in it is SKIPPED in exactly the states it
  //    exists to catch. Measured, not asserted: that shape (mutant M3) turns
  //    the bypass case and the prompt-only case RED. A rerun against a graph
  //    CEE never received is exactly as wrong as a first run.
  //  · ⚠ AND THE HONEST LIMIT OF THAT CLAIM, because a demonstrated-equivalent
  //    mutant is worth more than a confident comment (trap 13c): applying this
  //    SAME filter downstream, over the polished list, is behaviourally
  //    IDENTICAL for visibility — mutant M7 survived 12/12. Upstream is chosen
  //    so the dev-log counts below and the polish step both operate on the
  //    admissible set, NOT because visibility depends on the position.
  //  · UNCONDITIONALLY (not inside the `v5Active` branch), because the hold
  //    already carries the run-path conjunct itself — `analysisHeldOn` returns
  //    null off the V5 canonical path, where a run sends the canvas graph and
  //    the engine genuinely does see this model. Re-testing the run path here
  //    would be a second copy of that condition (trap 12).
  //
  // It removes ONLY run-analysis affordances: the hold refuses THE RUN, not the
  // conversation, and the chips that get the user out of the held state
  // (edit_graph, draft_graph, plain chat) must survive it. Detection is
  // `isRunAnalysisAffordance` — the SAME detector the polish step below already
  // uses, so a prompt-only "Rerun analysis" chip cannot slip through a narrower
  // `action_type`-only test, and there is no second predicate to drift.
  const admissible = heldOn === null ? chips : chips.filter((c) => !isRunAnalysisAffordance(c))

  const supported = v5Active
    ? admissible.filter((c) => {
        if (!c.action_type) return true
        const isV5Known = V5_ENABLED_ACTIONS.has(c.action_type)
        if (!isV5Known) return false
        const needsReadiness = READINESS_GATED_ACTIONS.has(c.action_type)
        // WIDENED (was `analysisStatus !== 'ready'`): CEE now publishes its own
        // admission verdict, which is ALSO true when the run will proceed by
        // excluding the options the user left open. That is the readiness loop's
        // payoff turn — `needs_user_input` AND runnable — where the old gate hid
        // the very affordance the turn had just offered. Disjunction, so nothing
        // that rendered before stops rendering; see `admitsRunAffordance`.
        if (needsReadiness && !admitsRunAffordance(analysisStatus, analysisMayRun)) {
          // Single bypass: run_analysis survives when the polish will
          // relabel it. The decision is upstream (`runAnalysisPolish`).
          if (c.action_type === 'run_analysis' && runAnalysisPolish === 'relabel-rerun') {
            return true
          }
          return false
        }
        return true
      })
    : admissible
  if (import.meta.env.DEV && v5Active) {
    const removedUnsupported = admissible.filter(
      (c) => c.action_type && !V5_ENABLED_ACTIONS.has(c.action_type),
    )
    const removedUnready = admissible.filter(
      (c) =>
        c.action_type &&
        V5_ENABLED_ACTIONS.has(c.action_type) &&
        READINESS_GATED_ACTIONS.has(c.action_type) &&
        // Mirrors the gate above, INCLUDING the may_run term — a dev log that
        // reported a chip as "removed for unreadiness" while the gate had in
        // fact admitted it would be a mirror telling a different story from the
        // code beside it.
        !admitsRunAffordance(analysisStatus, analysisMayRun) &&
        // Mirror the bypass — a chip that survived shouldn't show up as
        // "removed" in the dev log.
        !(c.action_type === 'run_analysis' && runAnalysisPolish === 'relabel-rerun'),
    )
    if (removedUnsupported.length > 0) {
      logV5StateEvent('chip_filter_unsupported', {
        count: removedUnsupported.length,
        action_types: removedUnsupported.map((c) => c.action_type ?? 'null'),
      })
    }
    if (removedUnready.length > 0) {
      logV5StateEvent('chip_filter_unready', {
        count: removedUnready.length,
        action_types: removedUnready.map((c) => c.action_type ?? 'null'),
        analysis_status: analysisStatus,
        analysis_may_run: analysisMayRun ?? null,
      })
    }
  }

  // aiPanelV2: apply the product rule to run-analysis affordances.
  // `runAnalysisPolish` was computed once upstream — the V5 filter and
  // this map step both consume the same value so they cannot diverge.
  // Detection covers both V2 chips (action_type === 'run_analysis') and
  // legacy prompt-style chips matched by the canonical regex.
  const polished = aiPanelV2On
    ? supported
        .filter((c) => !(isRunAnalysisAffordance(c) && runAnalysisPolish === 'suppress'))
        .map((c) =>
          isRunAnalysisAffordance(c) && runAnalysisPolish === 'relabel-rerun'
            ? { ...c, label: 'Rerun' }
            : c,
        )
    : supported

  // Ruled doctrine D-K (closed 15 Jul): 0-3 suggested action chips — render
  // up to 3 when offered, none when none offered (no filler). Supersedes the
  // DS v5 §21.4 "max 2" cap; the DS doc amendment is owned by the DS-1 lane.
  //
  // ROADMAP 2.138: the dispatchability guard is `isChipRenderable`, shared with
  // ActionChipRow and ChatThread. It used to be an inline `!!(message || prompt)`
  // here, which dropped the terminal notices' `start_new_draft` chip — a chip
  // ConversationPanel routes by id and which therefore carries no message.
  const visible = polished.filter(isChipRenderable).slice(0, 3)
  if (visible.length === 0) return null

  const disabled = isThinking || isHistorical

  // The host's gate, read verbatim. Closed ⇒ every Run chip in the row is
  // disabled. The sentence is the host's own (`runBlockedReason`); a blank or
  // absent one leaves the chip disabled with NO description rather than a
  // sentence this component made up.
  const runGateClosed = runGate !== undefined && !runGate.allowed
  const runGateReason =
    runGateClosed && typeof runGate.reason === 'string' && runGate.reason.trim().length > 0
      ? runGate.reason
      : undefined
  const showRunGateReason = runGateReason !== undefined && visible.some(isRunAnalysisAffordance)

  function handleClick(chip: ActionChip) {
    if (disabled) return
    const isRunChip = isRunAnalysisAffordance(chip)
    // Belt-and-braces: a gated Run chip is `disabled`, so no pointer or keyboard
    // activation reaches here. A programmatic path that did would still start
    // nothing.
    if (isRunChip && runGateClosed) return
    setChipError(null)
    /*
     * ⭐ A RUN CHIP ASKS THE RUN GATE, NOT THE CHAT (journey blocker, RC #63
     * 5819467504). This chip used to dispatch `run_analysis` straight through
     * `onChipClick`, consulting none of the six rungs of `canRunAnalysis` — so on
     * a graph-health error, a still-settling streamed draft or
     * `can_run_analysis:false` it started a run the panel's own Analyse control
     * refuses.
     *
     * Host passed a gate (`ConversationPanel`) ⇒ the click goes to
     * `onChipClick`. The host's `handleChipClick` recognises a Run chip with the
     * same `isRunAnalysisAffordance`, runs it through its gated runner (the one
     * behind the Analyse control) with the clicked chip's own label as the
     * transcript echo, and records the chip as taken for thread persistence.
     *
     * No gate passed ⇒ the previous path, unchanged: the guidance store's
     * registered `_runAnalysis` when there is one (it refuses out loud or
     * dispatches the canonical `run_analysis`), else `onChipClick`.
     */
    const gatedRun =
      isRunChip && runGate === undefined ? useGuidanceStore.getState()._runAnalysis : null
    if (gatedRun) {
      gatedRun()
      return
    }
    onChipClick(chip).catch(() => {
      setChipError("That didn't work. Try typing your request instead.")
    })
  }

  return (
    <div className="flex flex-col self-start gap-1 mb-4">
      <div
        className="flex flex-wrap gap-2 mt-4"
        data-testid="suggested-chips"
      >
        {visible.map((chip, i) => {
          const roleLabel = chip.role
            ? chip.role.charAt(0).toUpperCase() + chip.role.slice(1)
            : null
          const baseLabel = roleLabel
            ? `${roleLabel}: ${chip.label}`
            : chip.label
          // ⭐ THE APPLY CONTROL MUST SAY WHAT IT WOULD APPLY.
          //
          // CEE's readiness repair offer arrives here as an ordinary
          // `suggested_actions` entry — the readiness arm emits no
          // `held_proposal` block, so it can never reach `V5HeldProposalBlock`,
          // the one surface that already honoured this field. Its label counts
          // the changes ("Apply 3 safe model fixes"); `detail` is the only
          // place their descriptions — which NAME THE OPTIONS being altered —
          // appear. The user was being asked to authorise a mutation of their
          // own reasoning model with that list discarded on arrival.
          //
          // The rule is `V5HeldProposalBlock.tsx:209-216`'s, reused rather than
          // reinvented: trim; empty or equal to the label ⇒ the label already
          // says everything, so nothing is added; otherwise the accessible name
          // extends to `${visible}: ${detail}`. It EXTENDS the label, never
          // replaces it, and composes with the role prefix instead of
          // displacing it.
          //
          // Deliberately the accessible name + `title`, NOT a new visible row:
          // this file's chip grammar is owned by `CHIP_CLASS`, and a jsdom
          // suite cannot see a pixel, so a layout change here would be an
          // unmeasured one. The visible text stays `chip.label` exactly.
          const detailText = typeof chip.detail === 'string' ? chip.detail.trim() : ''
          const detailAdds = detailText.length > 0 && detailText !== chip.label
          const ariaLabel = detailAdds ? `${baseLabel}: ${detailText}` : baseLabel
          // Only Run chips answer to the run gate; every other chip stays live.
          const runGated = runGateClosed && isRunAnalysisAffordance(chip)
          const chipDisabled = disabled || runGated

          return (
            <button
              key={chip.id ?? `chip-${i}`}
              type="button"
              onClick={() => handleClick(chip)}
              disabled={chipDisabled}
              aria-label={ariaLabel}
              title={detailAdds ? detailText : undefined}
              aria-disabled={chipDisabled}
              aria-describedby={runGated && showRunGateReason ? runGateReasonId : undefined}
              data-run-gated={runGated ? 'true' : undefined}
              // PX-B (Paul, 15 Aug: "oversized actions"). The chip grammar —
              // and the down-size to `.chip`'s 12px/6px at 12px — lives in
              // CHIP_CLASS, which is the ONE authority for it. This file used
              // to carry a byte-identical copy of that string; the copy is
              // gone rather than edited in parallel, because two copies that
              // agree today are two copies that diverge at the next DS tweak
              // (this change is that tweak, and editing only this one would
              // have shipped two chip sizes into a single panel).
              //
              // Only the animation classes stay local: they are this surface's
              // stagger-in, not part of the shared idiom.
              className={`suggested-chip chip-stagger-in ${CHIP_CLASS}`}
              style={{ animationDelay: `${i * 70}ms` }}
              data-testid={`suggested-chip-${chip.id}`}
              data-chip-role={chip.role ?? undefined}
            >
              {chip.label}
            </button>
          )
        })}
      </div>

      {/* The gate's own sentence, verbatim, under the row it explains. It is
          the accessible description of every gated Run chip above, and it is
          visible because a disabled chip takes no hover (`CHIP_CLASS`
          `disabled:pointer-events-none`), so a tooltip would never show. */}
      {showRunGateReason && (
        <p
          id={runGateReasonId}
          className={`${typography.panelMeta} text-text-light`}
          style={{ margin: 0, paddingLeft: 2 }}
          data-testid="suggested-chips-run-gate-reason"
        >
          {runGateReason}
        </p>
      )}

      {chipError && (
        <p
          className={`${typography.bodySmall} text-danger`}
          style={{ margin: 0, paddingLeft: 2 }}
          data-testid="chip-error"
        >
          {chipError}
        </p>
      )}

      <style>{`
        @keyframes chipStaggerIn {
          from { opacity: 0; transform: translateY(5px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .chip-stagger-in {
          animation: chipStaggerIn 250ms cubic-bezier(0.4, 0, 0.2, 1) both;
        }
        .suggested-chip:not(:disabled):active {
          transform: scale(0.97);
          opacity: 0.85;
        }
        @media (prefers-reduced-motion: reduce) {
          .chip-stagger-in { animation: none; opacity: 1; }
          .suggested-chip:not(:disabled):active { transform: none; }
        }
      `}</style>
    </div>
  )
}
