/**
 * ChatThread — Zone 2: scrollable conversation thread.
 *
 * Renders EmptyState (no messages + no graph), ChatMessage list,
 * ThinkingIndicator, SuggestedChips, and "New messages" pill.
 * Custom scrollbar: 4px, themed. Smart scroll via useSmartScroll.
 */

import { memo } from 'react'
import { ArrowDown } from 'lucide-react'
import { typography } from '../../../styles/typography'
import { useSmartScroll } from '../hooks/useSmartScroll'
import { EmptyState } from './EmptyState'
import { ChatMessage } from './ChatMessage'
import type { HeldProposalSettlement } from '../../../v5/blocks/V5HeldProposalBlock'
import { SessionDivider } from '../primitives/SessionDivider'
import { ThinkingIndicator } from './ThinkingIndicator'
import { SuggestedChips, type RunChipGate } from './SuggestedChips'
import type { ConversationMessage, ActionChip, GraphPatchBlock } from '../types'
import type { PatchBlockState, PatchRejectionInfo } from '../useConversation'
import { useCanvasStore } from '../../store'
import { useDraftStore, draftStreamPhaseFor } from '../../stores/draftStore'
import { SETTLING_STAGES, SETTLING_AFTER_COACHING_STAGES } from '../../components/DraftLoadingAnimation'

/**
 * ⭐ MOUNT IDENTITY — the two conversation surfaces' THREAD CONTAINERS must
 * never answer to the same name.
 *
 * ⚠ READ THE SCOPE BEFORE RELYING ON THIS. What is split is the container, and
 * ONLY the container. `testId` is consumed at exactly one place in this file
 * (the `data-testid` on the scroll container below) and is forwarded to no
 * child, so EVERY descendant testid is still built from content alone and is
 * still duplicated across the two hosts. The concrete case that started this
 * lane is among them: the run chip's id comes from chip data
 * (`SuggestedChips.tsx`, `` `suggested-chip-${chip.id}` ``), so
 * `suggested-chip-run_analysis` STILL resolves to two live elements whenever
 * both hosts are mounted, and a probe selecting it is still ambiguous.
 *
 * So the honest claim is narrow: a probe can now name WHICH THREAD it means,
 * and it must scope any descendant query to that container
 * (`within(getByTestId(THREAD_TESTID_DOCKED))`) rather than querying the
 * document. Unscoped descendant selectors are exactly as ambiguous as they
 * were before this change. Threading a host prefix through every descendant
 * testid is the fix that would make the broad claim true; it is not done here,
 * and it would be a repo-wide change to selectors and e2e specs.
 *
 * `ConversationPanel` has two production hosts (`OlumiTabBody.tsx:106`, the
 * docked Olumi tab, and `FloatingOlumiPanel.tsx:1079`), and they are NOT
 * mutually exclusive. `olumiSurface.ts`'s guard (`dockHostsOlumi`) yields the
 * floating panel only when the dock is open AND its tab is `olumi`; on every
 * other tab the docked host stays MOUNTED behind `hidden`
 * (`OutputsDock.tsx:3271-3279`, kept mounted on purpose so scroll position and
 * `useSmartScroll` state survive a tab switch) while the floating panel renders
 * too. That guard was written for VISIBLE exclusivity — `olumiSurface.ts:4-5`
 * says "exactly one may be visible" — and mount exclusivity was never claimed.
 *
 * So both hosts really do mount a thread at once, and until now both CONTAINERS
 * answered to `chat-thread`. Measured consequence, in real Chromium: the hidden twin is
 * `display:none`, 0x0, `hitTestable: false` — which means it can never take a
 * click from a HUMAN, but it absolutely can take one from anything selecting by
 * testid. A probe that resolves `chat-thread` to the wrong twin measures an
 * element no user is looking at and reports a working affordance as dead.
 *
 * The DOCKED tab is canonical and keeps the plain name, because it is the host
 * `dockHostsOlumi` already makes the winner whenever both could serve, and the
 * one deliberately kept alive across tab switches. Both names live HERE, once,
 * so a rename cannot land on one host and miss the other.
 */
export const THREAD_TESTID_DOCKED = 'chat-thread'
export const THREAD_TESTID_FLOATING = 'chat-thread-floating'

/**
 * The element `useSmartScroll` aims `scrollIntoView` at (`useSmartScroll.ts:63`
 * and `:70` — the only two call sites). Exported so no spec has to identify it
 * by a property other elements share: `OutputsDock.runReturnsToOlumi.spec.tsx`
 * used to find it as "the scrolled element that has NO `data-testid`", which
 * any untagged element satisfied and which this constant's very existence
 * would have broken (it did — that spec is updated in the same commit).
 * One literal, one place (CLAUDE.md trap 12).
 */
export const THREAD_SCROLL_SENTINEL_TESTID = 'thread-scroll-sentinel'

interface ChatThreadProps {
  messages: ConversationMessage[]
  isThinking: boolean
  longRunningHint: string | null
  nodeCount: number
  patchBlockStates: Map<string, PatchBlockState>
  patchRejections: Map<string, PatchRejectionInfo>
  onChipClick: (chip: ActionChip) => Promise<void>
  onPatchAccept: (key: string, block: GraphPatchBlock) => void
  onPatchDismiss: (key: string) => void
  onFeedback: (turnId: string, rating: 'up' | 'down') => void
  onRetry: () => void
  onArtefactMessage?: (message: string) => void
  onProposalConfirm?: (proposalId: string) => void
  /** SENDABLE failure 5 — record a held proposal's settlement in the shared
   *  `patchBlockStates` registry, for every copy on screen when the user acts:
   *  both surfaces, and every earlier turn re-issuing the same handle. */
  onHeldProposalSettle?: (
    proposalId: string,
    settlement: HeldProposalSettlement,
    turnId?: string,
  ) => void
  /** AI panel v2 surface — render message body at panelBody (12px). */
  compact?: boolean
  /**
   * External handle so the parent can capture/restore the thread's
   * scroll position across mode transitions (AI panel v2 Compact ↔
   * Focus). When provided, the thread populates it with the scroll
   * container ref.
   *
   * ⚠ THIS COMMENT USED TO CLAIM A SUPPRESSION MECHANISM THAT DOES NOT EXIST:
   * "the smart-scroll auto-pin to bottom is suppressed on the FIRST layout after
   * re-mount so a parent-driven restoreScrollTop call wins." `useSmartScroll`
   * takes `{ messageCount, isThinking }` and nothing else — there is no
   * suppression parameter, this ref is never passed to the hook, and no
   * `restoreScrollTop` exists anywhere in the tree. Corrected rather than deleted
   * (CLAUDE.md trap 14: a false label teaches the next reader to stop looking, and
   * this one would have sent them hunting a suppression bug to explain the
   * missing first-reply scroll — which had an entirely different cause, recorded
   * at the trigger below).
   */
  scrollListRef?: React.MutableRefObject<HTMLDivElement | null>
  /**
   * Which conversation surface this thread IS. Defaults to the canonical
   * docked identity; the floating host passes `THREAD_TESTID_FLOATING`.
   * See the mount-identity note above.
   */
  testId?: string
  /**
   * The host's run-gate verdict, forwarded untouched to `SuggestedChips` so a
   * Run chip renders disabled with the gate's own sentence instead of looking
   * live and refusing on click. Optional: absent ⇒ the chip row behaves exactly
   * as before. See `RunChipGate`.
   */
  runGate?: RunChipGate
}

/**
 * Which half of the streamed draft's settling window the thread is in.
 * 'none' covers every non-settling state, including the whole buffered path
 * (which has no such window — the graph and the turn land together).
 */
type DraftSettlingState = 'none' | 'settling' | 'after_coaching'

/**
 * Derive a thinking label from the hint.
 *
 * PX-B (Paul's 15 Aug testing: "an unexplained still-thinking state after the
 * model appears"). During the streamed draft's SETTLING window the thread used
 * to render `longRunningHint` unchanged \u2014 and nothing updates that hint at
 * GRAPH_READY, so for the ~25 s measured settling window
 * (GRAPH_READY 35.8 s \u2192 COMPLETE 60.9 s, useConversation.ts) the thread said
 * "Building your decision model\u2026 45s" ABOUT A MODEL ALREADY ON THE CANVAS,
 * while the composer three inches below said "Your model is on the canvas.
 * Values and coaching are still arriving\u2026". Two surfaces, one moment,
 * contradicting each other \u2014 not a silence, a lie.
 *
 * What is actually happening in that window, derived at the CEE bytes
 * (`unified-pipeline/index.ts`): the graph is emitted at GRAPH_READY BEFORE the
 * expensive work, and the window is dominated by ONE bounded LLM call \u2014 the
 * Stage 4.5 coaching pass (measured `coaching_pass_ms`: median 20.8 s, n=40) \u2014
 * writing coaching and causal claims about a structure that is already final,
 * with the per-edge validation pass settling concurrently. "Values and coaching
 * are still arriving" is exactly that, and no more than that.
 *
 * So this reuses the SETTLING tables verbatim rather than writing new copy:
 * they are already ratified against the cross-surface narration-honesty
 * invariant (`narrationHonesty.invariant.spec.ts` \u2014 no pipeline-stage claim,
 * no completion-proximity, no claim the frame does not license), and inventing
 * a second sentence for the same moment is how the two surfaces diverged in the
 * first place. The elapsed clock deliberately stays with the composer, which
 * owns it; the thread takes the base line for its phase.
 */
function thinkingLabel(hint: string | null, settling: DraftSettlingState): string {
  if (settling === 'after_coaching') return SETTLING_AFTER_COACHING_STAGES[0].message
  if (settling === 'settling') return SETTLING_STAGES[0].message
  if (hint) return hint
  return 'Thinking\u2026'
}

export const ChatThread = memo(function ChatThread({
  messages,
  isThinking,
  longRunningHint,
  nodeCount,
  patchBlockStates,
  patchRejections,
  onChipClick,
  onPatchAccept,
  onPatchDismiss,
  onFeedback,
  onRetry,
  onArtefactMessage,
  onProposalConfirm,
  onHeldProposalSettle,
  compact,
  scrollListRef,
  testId = THREAD_TESTID_DOCKED,
  runGate,
}: ChatThreadProps) {
  // Has the conversation produced any finalized (non-streaming) assistant messages?
  const hasFinalizedAssistant = messages.some(m => m.role === 'assistant' && !m.isStreaming)

  // EmptyState stays visible when no graph nodes exist and no finalized assistant
  // response has arrived. This keeps the shape pipeline on screen during the first
  // turn (Generate Model or first chat message) so it can serve as the loading hub.
  const showEmptyState = nodeCount === 0 && !hasFinalizedAssistant

  /**
   * THE SINGLE PREDICATE deciding whether a message reaches the DOM. The render
   * map below and the scroll trigger above BOTH consume it, so the two can never
   * drift apart (CLAUDE.md trap 12: a second copy of this rule would be a
   * hand-maintained mirror, and its drift would read as green).
   *
   * ⚠ WHY THE SCROLL TRIGGER IS THE RENDERED COUNT AND NOT `messages.length`.
   * Measured on deployed staging (L3 browser truth): after the first assistant
   * reply the thread sat at `scrollTop 0` against `scrollHeight ~1351` — the
   * reply was below the fold and nothing scrolled to it. `messages.length` DOES
   * change during the first turn (0 → 1 user → 2 streaming), so the effect fired
   * twice — but on both commits this predicate returned false for every message,
   * so it scrolled a container holding only `EmptyState`. The commit that finally
   * puts content on screen is `hasFinalizedAssistant` flipping true, which happens
   * by MUTATING an existing message's `isStreaming` — `messages.length` is
   * IDENTICAL across it, so the old trigger could not observe the one commit that
   * mattered. Counting rendered messages makes the trigger fire on that commit,
   * because 0 → 2 is exactly the transition the user sees.
   */
  const isRendered = (msg: ConversationMessage): boolean =>
    !(showEmptyState && (msg.role === 'user' || msg.isStreaming))

  let renderedMessageCount = 0
  for (const m of messages) if (isRendered(m)) renderedMessageCount++

  const { listRef, listEndRef, showNewMessageIndicator, handleScroll, scrollToBottom } =
    useSmartScroll({ messageCount: renderedMessageCount, isThinking })

  // Mirror the internal listRef into an externally-provided ref so the
  // parent (AI panel v2 layout) can capture and restore scrollTop
  // across mode transitions. The mirror runs on every commit so the
  // external ref tracks list re-mounts on resize.
  if (scrollListRef) {
    scrollListRef.current = listRef.current
  }

  // While EmptyState is showing, extract streaming text from the first streaming
  // message so it can be displayed below the shapes instead of in a message bubble.
  const streamingMsg = showEmptyState ? messages.find(m => m.isStreaming) : undefined
  const streamingText = streamingMsg?.content || null

  if (import.meta.env.DEV) {
    console.debug('[ChatThread] showEmptyState=%s isThinking=%s nodeCount=%d hasFinalizedAssistant=%s msgs=%d streamingText=%s',
      showEmptyState, isThinking, nodeCount, hasFinalizedAssistant, messages.length, !!streamingText)
  }

  // Transcript honesty (trust item #3): the retry affordance on a failed
  // user message is wired ONLY for the message retryLast would actually
  // resend — the LAST user message. Older failed attempts keep the
  // "Not delivered" marker without a retry button (clicking retry there
  // would resend different text than the bubble shows).
  // One backwards pass captures both last-of-role messages. Previously this
  // was two `[...messages].reverse().find(...)` chains — two full array copies
  // plus two reverses per render, on a path that runs ~60x/sec once streaming
  // is enabled.
  let lastUserMsg: ConversationMessage | undefined
  let lastAssistantMsg: ConversationMessage | undefined
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    if (!lastUserMsg && m.role === 'user') lastUserMsg = m
    if (!lastAssistantMsg && m.role === 'assistant') lastAssistantMsg = m
    if (lastUserMsg && lastAssistantMsg) break
  }
  const failedSendRetryId =
    lastUserMsg && lastUserMsg.deliveryState === 'failed' ? lastUserMsg.id : null

  // Get suggested chips from last assistant message.
  //
  // `SuggestedChips` below is the SOLE render surface for `actionChips`
  // (verified at 4fbc6451: `<ActionChipRow` has zero production render sites,
  // and `MessageBubble` renders no chips). Until 2026-08-07 this line was
  // followed by a `suggestedChipsWillRender` predicate feeding a `hideChips`
  // prop down ChatMessage → MessageBubble to "suppress the inline
  // ActionChipRow". MessageBubble declared that prop and never destructured
  // it: the whole chain was inert, and its comments described a suppression
  // mechanism that no longer had anything to suppress. Removed rather than
  // re-documented — a dead guard that reads as a live one is how ROADMAP
  // 2.668's second defect came to be diagnosed against this file at all.
  const suggestedChips = lastAssistantMsg?.actionChips ?? []

  // PX-B: the settling phase, read the SAME way AIInputBar reads it —
  // `draftStreamPhaseFor` is the one place that decides scenario ownership, so
  // a stale stream from another scenario cannot narrate over this one.
  const currentScenarioId = useCanvasStore((s) => s.currentScenarioId)
  const draftStreamPhase = useDraftStore((s) => draftStreamPhaseFor(s, currentScenarioId))
  // Read as a CONJUNCT of the settling phase, never bare (same rule as
  // AIInputBar): coachingLanded is not scenario-scoped on its own.
  const coachingLanded = useDraftStore((s) => s.draftStreamCoachingLanded)
  const settlingState: DraftSettlingState =
    draftStreamPhase !== 'settling' ? 'none' : coachingLanded ? 'after_coaching' : 'settling'

  return (
    <div
      ref={listRef}
      className="chat-thread olumi-scrollbar flex flex-col flex-1 min-h-0 overflow-y-auto bg-panel"
      style={{ padding: '20px 16px 8px' }}
      onScroll={handleScroll}
      role="log"
      aria-label="Conversation"
      aria-live="polite"
      data-testid={testId}
    >
      {showEmptyState && (
        <EmptyState
          animate={isThinking}
          statusLabel={isThinking ? thinkingLabel(longRunningHint, settlingState) : null}
          streamingText={streamingText}
        />
      )}

      {messages.map((msg) => {
        // Hide user messages and the streaming placeholder while EmptyState is the loading hub.
        // Same predicate the scroll trigger counts with — derived, never restated.
        if (!isRendered(msg)) return null
        const isLastAssistant = msg === lastAssistantMsg
        if (msg.sessionDivider) {
          return <SessionDivider key={msg.id} text={msg.sessionDivider} />
        }
        const chatMsg = (
          <ChatMessage
            key={msg.id}
            message={msg}
            onChipClick={onChipClick}
            onRetry={onRetry}
            showFailedSendRetry={msg.id === failedSendRetryId}
            // L-42: `isLastAssistant` is the identity ChatThread ALREADY
            // derives for the chip row; reusing it means the staleness voice
            // and the chips can never disagree about which turn is current.
            isLatestAssistantTurn={isLastAssistant}
            patchBlockStates={patchBlockStates}
            patchRejections={patchRejections}
            onPatchAccept={onPatchAccept}
            onPatchDismiss={onPatchDismiss}
            onFeedback={onFeedback}
            onArtefactMessage={onArtefactMessage}
            onProposalConfirm={onProposalConfirm}
            onHeldProposalSettle={onHeldProposalSettle}
            compact={compact}
          />
        )
        // Attach suggested chips directly below the last assistant message
        // so they read as one visual unit rather than floating orphans.
        if (isLastAssistant && suggestedChips.length > 0) {
          return (
            <div key={msg.id} className="response-chip-group" data-testid="response-chip-group">
              {chatMsg}
              <SuggestedChips
                chips={suggestedChips}
                onChipClick={onChipClick}
                isThinking={isThinking}
                runGate={runGate}
              />
            </div>
          )
        }
        return chatMsg
      })}

      {/* ThinkingIndicator: only when EmptyState is NOT handling the loading display */}
      {isThinking && !showEmptyState && !messages.some(m => m.isStreaming) && (
        <ThinkingIndicator label={thinkingLabel(longRunningHint, settlingState)} />
      )}

      {/* New messages pill */}
      {showNewMessageIndicator && (
        <button
          type="button"
          onClick={scrollToBottom}
          className={`
            sticky bottom-2 self-center z-10
            inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full
            bg-transparent border border-info/30 text-text-body
            ${typography.panelMeta} font-medium
            cursor-pointer
          `}
          style={{ boxShadow: 'var(--shadow-2, 0 4px 12px rgba(0,0,0,0.08))' }}
          data-testid="new-messages-pill"
        >
          <ArrowDown className="w-3 h-3" aria-hidden="true" />
          New messages
        </button>
      )}

      {/* The scroll sentinel `useSmartScroll` calls `scrollIntoView` on. It
          carries a testid so a spec can assert the scroll was aimed at THIS
          element by identity, rather than counting calls on a globally stubbed
          `Element.prototype.scrollIntoView` that any element would satisfy
          (CLAUDE.md trap 19). */}
      <div ref={listEndRef} data-testid={THREAD_SCROLL_SENTINEL_TESTID} />
    </div>
  )
})
