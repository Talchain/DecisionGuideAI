**Risk: NOT LOW** (a user-visible claim surface; a new UI-SEM row). Opened on RC's grant (#69 5829186806 §2). **File-disjoint from U4:** measured against #1985 `647de9b5`, #1984 `8bd9019f`, #1991 `6cd8be38`, #1999 `284670f8` and #2001 `b476866f`. No `scripts/ci/*baseline*` file keys this component.

## What the user gets
On a Run where the producer **withholds the leader claim**, the chat's **Analysis result** card no longer lists the options by win share, largest first.

**Served defect** (final tuple UI `b017e3c2` · CEE `9417228`, reviewer 5827478637):
- The reply said "No option can be put forward yet".
- The card beside it printed **Raise to £59 at Release · 82%**, **Keep £49 Price · 16%**, **Raise to £55 at Release · 2%**.
- AI Quality measured this on 29 of 30 served explicit Runs (5827505713).

An ordered list of win shares **is** a ranking, which is the claim the producer declined to make (the C2 rule).

## The rule (UI-SEM-097, new `CLAUDE.md` row, ACKed by RC 5827762655 §1)
The pill row is hidden when EITHER of these holds:
- **this run named no leader:** `leading_option_id` is null or blank. CEE nulls it on a withheld claim while the probabilities keep riding the wire;
- **the held report carries the producer's refusal:** `producer_leader_permission`, stamped by `applyV5State` from the typed `leader_claim` and read only through `readProducerLeaderPermission`.

Details:
- **Fails closed.** The per-card half keeps an earlier withheld run (null id) withheld after a later run permits.
- **Guarantee, narrowed** (pre-review 5829256617, confirmed on the mounted chain):
  - The per-card guarantee rests on CEE's contract that a withheld claim nulls `leading_option_id` (CEE #711; 105/105 served).
  - The held-report half covers only the card whose report is currently held.
  - A withheld claim that kept a non-null id (never observed) would show its row again after a later permitted Run.
  - The true per-card fix stamps the turn's `leader_claim` onto the block at ingestion. It needs `useConversation.ts`, which is G1's file in U4, so it is a follow-up right after U4.
- **Suppression only.** The summary, prose, named metrics and uncertainty line are untouched. A near tie the producer *permits* keeps its `leading_option_id`, so it is unaffected; a withheld near tie is hidden like any withheld run.
- **Observed invariant** (the pre-review asked for it): AI Quality measured null `leading_option_id` together with `permitted:false` on 105/105 served withheld blocks and 11/11 permitted ones. Each half of the gate still withholds on its own, and the tests below prove both.

## Tests (jsdom; NO model calls)
**1. `withheldLeaderMountedChain.spec.tsx` (new, 8 tests).** This is pre-review 5829070993's ask, run through the shipped chain:
- **The chain:** the served body goes through the real `useConversation` → `applyV5State` → `ConversationPanel` → `MessageBubble` → `InlineBlocks` → card. `fetch` answers from the capture.
- **What each case asserts:** what a guest **sees** (no row, no ranked list, no "label · N%" text) and **hears** (no accessible name that announces a share).

| Case | Bytes | Result |
|---|---|---|
| Withheld, separated, 83/15/1 | served `57f903c` (OpenAI route) | no row; summary intact; the refusal landed in both places the gate reads |
| The witnessed 82/16/2 | derived: the review's quoted values on the `57f903c` body (the witness bytes are on the laptop) | no row |
| Withheld near tie, 53/47/<1 | served `e39f6e0` C1 → C2 | no row |
| Claim withheld, block names a leader | derived; never seen on the wire | no row (the percentages carry their own permission check) |
| **Permitted control** | derived from `57f903c`: claim permitted, rank-1 option id | every share, largest first, under "Share of simulated scenarios supporting each option" |
| Withheld Run, then permitted Run | served + derived | the earlier card stays withheld; the later one renders |

- **RED on the staging source:** 5 of 8 fail.
- **Mutants:** gating on `leading_option_id` only → 1 fails; on the held report only → 1 fails.

**2. `withheldLeaderRanksNothing.spec.tsx` (new, 8 tests)**, on the served `e39f6e0` C2 block through `mapV5Blocks`. RED on the staging source: 3 of 8.

**3. Updated specs:** `leaderIdentity` (3) and `withheldProse` (2) now assert no row when the claim is withheld.

**Local results:**
- `src/v5/blocks`: 31 files, 448 tests green.
- Typecheck gate PASSED.
- ESLint: 0 errors.

**Browser check** (witness §14 @ `96ca2952`, posted 5827900859):
- the fix build's card has no win-share row, while staging shows 53/47/<1%;
- everything else renders identically;
- 0 off-origin requests.

## Not covered
- A served witness on this PR's deploy. It follows RC's train and Paul's go.
- **The prose itself.** On `57f903c` the assistant text above the card states "83.28% of runs … versus 15.39%". That is CEE copy, handled in CEE #1871 (the quantifier exemption), not here.
- The other five leak surfaces belong to Panel and Canvas (#2001, leak 1, leak 5).
- **Exploratory admission or a near tie:** the row stays, uncrowned but sorted largest-first. Existing reviewed pins keep the numbers there. Whether that order is itself a ranking is raised with RC as a ruling; I recommend the producer's order.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Q5bxkDMkNnEcRXKYsV9zEa
