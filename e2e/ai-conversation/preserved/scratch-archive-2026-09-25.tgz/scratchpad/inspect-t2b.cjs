const f = require('/home/user/cee-prb-wt/src/orchestrator-v5/coaching/__tests__/fixtures/c19-8428207-B.run-turns.trimmed.json');
const t = f.turns.t2;
console.log(JSON.stringify(t.analysis_result, null, 1).slice(0, 6000));
console.log(JSON.stringify(t.analysis_ready, null, 1).slice(0, 2000));
console.log(JSON.stringify(t.tools_called));
