import subprocess, re, os
ROOT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-a4dfcf1d3a7f83ed0'
F = os.path.join(ROOT, 'src/canvas/stores/readinessStore.ts')
orig = open(F).read()
LINE = 'const retainedVerdictIsLocal = readiness !== null && verdictAtMs === null'
assert orig.count(LINE) == 1


def arm(old_call, new_call):
    assert orig.count(old_call) == 1, old_call
    return orig.replace(old_call, new_call)


mutants = {
    'M1 no drop (helper retains local verdict)': orig.replace(LINE, 'const retainedVerdictIsLocal = false && readiness !== null && verdictAtMs === null'),
    'M2 drop ANY verdict (server answers too)': orig.replace(LINE, 'const retainedVerdictIsLocal = readiness !== null'),
    'M3 inverted discriminator (verdictAtMs !== null)': orig.replace(LINE, 'const retainedVerdictIsLocal = readiness !== null && verdictAtMs !== null'),
    'M4 helper also clears stale': orig.replace("    loading: false,\n    ...(retainedVerdictIsLocal", "    loading: false,\n    stale: false,\n    ...(retainedVerdictIsLocal"),
    'M5a transport arm bypasses helper': arm("        console.warn(`[readinessStore] ${message} — publishing no verdict:`, fetchErr)\n        publishCheckFailure(message)", "        console.warn(`[readinessStore] ${message} — publishing no verdict:`, fetchErr)\n        useReadinessStore.setState({ error: message, loading: false })"),
    'M5b 429 arm bypasses helper': arm("publishCheckFailure('Could not check readiness right now — the service is rate limited')", "useReadinessStore.setState({ error: 'Could not check readiness right now — the service is rate limited', loading: false })"),
    'M5c 404 arm bypasses helper': arm("            response.errorBody,\n          )\n          publishCheckFailure(message)", "            response.errorBody,\n          )\n          useReadinessStore.setState({ error: message, loading: false })"),
    'M5d malformed-200 arm bypasses helper': arm("publishCheckFailure('Could not read the readiness service response')", "useReadinessStore.setState({ error: 'Could not read the readiness service response', loading: false })"),
    'M5e 5xx arm bypasses helper': arm("      console.warn(`[readinessStore] ${message} — publishing no verdict:`, err)\n      publishCheckFailure(message)", "      console.warn(`[readinessStore] ${message} — publishing no verdict:`, err)\n      useReadinessStore.setState({ error: message, loading: false })"),
}
specs = [
    'src/canvas/stores/__tests__/readinessStore.localVerdictOnFailedRecheck.spec.ts',
    'src/canvas/stores/__tests__/readinessStore.serverError.spec.ts',
    'src/canvas/stores/__tests__/readinessStore.unreachable.spec.ts',
    'src/canvas/stores/__tests__/readinessStore.notFound.spec.tsx',
    'src/canvas/stores/__tests__/readinessStore.rateLimited.spec.ts',
    'src/canvas/stores/__tests__/readinessStore.malformedOk.spec.ts',
]
env = dict(os.environ, VITE_SUPABASE_URL='http://localhost', VITE_SUPABASE_ANON_KEY='test')
try:
    for name, src in mutants.items():
        assert src != orig, name
        open(F, 'w').write(src)
        p = subprocess.run(['npx', 'vitest', 'run', *specs], cwd=ROOT, env=env, capture_output=True, text=True, timeout=600)
        out = p.stdout + p.stderr
        tests = re.search(r'Tests\s+(.*)', out)
        failed = sorted(set(re.findall(r'FAIL\s+(\S+) > (.*)', out)))
        print(f'== {name}: exit={p.returncode} :: {tests.group(1).strip() if tests else "?"}')
        for f, t in failed[:12]:
            print('   RED', os.path.basename(f), '>', t[:160])
finally:
    open(F, 'w').write(orig)
print('restored', open(F).read() == orig)
