// Provider-free guard for local test runs: any fetch to a non-loopback host throws before any network I/O.
const realFetch = globalThis.fetch;
const blocked = (async (input: unknown, init?: unknown) => {
  const url = typeof input === 'string' ? input : input instanceof URL ? input.href : String((input as { url?: unknown })?.url ?? input);
  if (/^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/.test(url)) return realFetch(input as never, init as never);
  throw new Error(`BLOCKED non-local fetch in provider-free test run: ${url}`);
}) as typeof fetch;
globalThis.fetch = blocked;
