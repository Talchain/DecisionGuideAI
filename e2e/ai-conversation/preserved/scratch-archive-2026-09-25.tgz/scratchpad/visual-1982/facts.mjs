// Dump the DOM facts recorded after each capture, A vs B side by side.
import { readFileSync } from 'node:fs'
const ROOT = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982/raw'
const [state, vp, mode = 'dock'] = process.argv.slice(2)
for (const side of ['A', 'B']) {
  const f = JSON.parse(readFileSync(`${ROOT}/${side}/${state}--${vp}--r0.json`, 'utf8'))
  console.log(`\n=========== ${side}  ${state} ${vp}`)
  console.log('readiness store:', JSON.stringify(f.facts.readiness))
  console.log('footer:', JSON.stringify(f.facts.footerText))
  console.log('dockBox:', JSON.stringify(f.facts.dockBox))
  if (mode === 'dock' || mode === 'all') {
    console.log('dockText:', JSON.stringify(f.facts.dockText))
    console.log('dock buttons:')
    for (const b of f.facts.buttons.filter((b) => b.inDock))
      console.log('   ', JSON.stringify({ t: b.testid, a: b.aria, x: b.text, dis: b.disabled, ariaDis: b.ariaDisabled, title: b.title, box: b.box }))
  }
  if (mode === 'page' || mode === 'all') {
    console.log('non-dock buttons:')
    for (const b of f.facts.buttons.filter((b) => !b.inDock))
      console.log('   ', JSON.stringify({ t: b.testid, a: b.aria, x: b.text, dis: b.disabled, ariaDis: b.ariaDisabled, title: b.title, box: b.box }))
    console.log('viewportTransform:', f.facts.viewportTransform)
  }
  console.log('bff/api responses:', JSON.stringify(f.responses))
  const offOrigin = f.requests.filter((r) => !/\/\/(localhost|127\.0\.0\.1)[:/]/.test(r))
  console.log('off-origin requests:', JSON.stringify(offOrigin))
  console.log('failed:', JSON.stringify(f.failed))
}
