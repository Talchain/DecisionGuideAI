// A-vs-B pixel comparison for PR #1982. Uses the repo's own pngjs + pixelmatch.
import { createRequire } from 'node:module'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

const WT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-a7e8597930bafc021'
const require = createRequire(join(WT, 'package.json'))
const { PNG } = require('pngjs')
const pixelmatch = require('pixelmatch')

const ROOT = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982'
const OUT = join(ROOT, 'work')
mkdirSync(OUT, { recursive: true })

const STATES = ['fresh-draft', 'model-tab', 'olumi-tab']
const VPS = ['1440x900', '1280x800']

const load = (p) => PNG.sync.read(readFileSync(p))

function compare(a, b, threshold = 0.2) {
  if (a.width !== b.width || a.height !== b.height) {
    return { sizeMismatch: [a.width, a.height, b.width, b.height] }
  }
  const diff = new PNG({ width: a.width, height: a.height })
  const n = pixelmatch(a.data, b.data, diff.data, a.width, a.height, { threshold, alpha: 0.15, diffColor: [255, 0, 0], aaColor: [255, 200, 0] })
  let exact = 0
  const mask = new Uint8Array(a.width * a.height)
  const pmMask = new Uint8Array(a.width * a.height)
  const maxDelta = new Uint8Array(a.width * a.height)
  for (let i = 0, p = 0; i < a.data.length; i += 4, p++) {
    if (a.data[i] !== b.data[i] || a.data[i + 1] !== b.data[i + 1] || a.data[i + 2] !== b.data[i + 2] || a.data[i + 3] !== b.data[i + 3]) {
      exact++
      mask[p] = 1
      maxDelta[p] = Math.max(Math.abs(a.data[i] - b.data[i]), Math.abs(a.data[i + 1] - b.data[i + 1]), Math.abs(a.data[i + 2] - b.data[i + 2]))
    }
    if (diff.data[i] === 255 && diff.data[i + 1] === 0 && diff.data[i + 2] === 0) pmMask[p] = 1
  }
  return { n, exact, diff, mask, pmMask, maxDelta, w: a.width, h: a.height }
}

// Regions: 4px cells, dilated 4 cells, connected components.
function regions(mask, w, h) {
  const C = 4
  const cw = Math.ceil(w / C), ch = Math.ceil(h / C)
  const cell = new Uint8Array(cw * ch)
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (mask[y * w + x]) cell[((y / C) | 0) * cw + ((x / C) | 0)] = 1
  const D = 4
  const dil = new Uint8Array(cw * ch)
  for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) if (cell[y * cw + x]) {
    for (let dy = -D; dy <= D; dy++) for (let dx = -D; dx <= D; dx++) {
      const yy = y + dy, xx = x + dx
      if (yy >= 0 && yy < ch && xx >= 0 && xx < cw) dil[yy * cw + xx] = 1
    }
  }
  const lab = new Int32Array(cw * ch).fill(-1)
  const out = []
  for (let i = 0; i < cw * ch; i++) {
    if (!dil[i] || lab[i] >= 0) continue
    const id = out.length
    let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1
    const st = [i]; lab[i] = id
    while (st.length) {
      const j = st.pop(); const x = j % cw, y = (j / cw) | 0
      if (cell[j]) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y) }
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const xx = x + dx, yy = y + dy
        if (xx < 0 || yy < 0 || xx >= cw || yy >= ch) continue
        const k = yy * cw + xx
        if (dil[k] && lab[k] < 0) { lab[k] = id; st.push(k) }
      }
    }
    if (x1 >= 0) {
      const bx = { x: x0 * C, y: y0 * C, w: Math.min(w, (x1 + 1) * C) - x0 * C, h: Math.min(h, (y1 + 1) * C) - y0 * C }
      let px = 0
      for (let y = bx.y; y < bx.y + bx.h; y++) for (let x = bx.x; x < bx.x + bx.w; x++) px += mask[y * w + x]
      out.push({ ...bx, px })
    }
  }
  return out.sort((a, b) => b.px - a.px)
}

const summary = {}
for (const s of STATES) for (const v of VPS) {
  const key = `${s}--${v}`
  const A0 = load(join(ROOT, 'raw/A', `${key}--r0.png`))
  const A1 = load(join(ROOT, 'raw/A', `${key}--r1.png`))
  const B0 = load(join(ROOT, 'raw/B', `${key}--r0.png`))
  const B1 = load(join(ROOT, 'raw/B', `${key}--r1.png`))
  const nA = compare(A0, A1)
  const nB = compare(B0, B1)
  const ab = compare(A0, B0)
  const rec = {
    size: [A0.width, A0.height, B0.width, B0.height],
    noiseA: { pm: nA.n, exact: nA.exact, sizeMismatch: nA.sizeMismatch },
    noiseB: { pm: nB.n, exact: nB.exact, sizeMismatch: nB.sizeMismatch },
    AvsB: { pm: ab.n, exact: ab.exact, sizeMismatch: ab.sizeMismatch },
  }
  const annotate = (cmp, rs) => rs.map((g) => {
    let pm = 0, md = 0
    for (let y = g.y; y < g.y + g.h; y++) for (let x = g.x; x < g.x + g.w; x++) {
      pm += cmp.pmMask[y * cmp.w + x]
      md = Math.max(md, cmp.maxDelta[y * cmp.w + x])
    }
    return { ...g, pm, maxChannelDelta: md }
  })
  if (!ab.sizeMismatch) {
    writeFileSync(join(OUT, `${key}--diff.png`), PNG.sync.write(ab.diff))
    rec.regions = annotate(ab, regions(ab.mask, ab.w, ab.h))
    rec.pmRegions = annotate(ab, regions(ab.pmMask, ab.w, ab.h))
  }
  if (!nA.sizeMismatch) rec.noiseARegions = annotate(nA, regions(nA.mask, nA.w, nA.h))
  if (!nB.sizeMismatch) rec.noiseBRegions = annotate(nB, regions(nB.mask, nB.w, nB.h))
  summary[key] = rec
}
writeFileSync(join(OUT, 'summary.json'), JSON.stringify(summary, null, 2))
const fmt = (g) => `x${g.x} y${g.y} ${g.w}x${g.h} exact=${g.px} pm=${g.pm} maxΔ=${g.maxChannelDelta}`
for (const [k, r] of Object.entries(summary)) {
  console.log(k, 'size', r.size.join('x'), '| noise A pm/exact', r.noiseA.pm, '/', r.noiseA.exact, '| noise B', r.noiseB.pm, '/', r.noiseB.exact, '| A vs B', r.AvsB.pm, '/', r.AvsB.exact, r.AvsB.sizeMismatch ?? '')
  for (const g of r.pmRegions ?? []) console.log('   PM region    ', fmt(g))
  for (const g of r.regions ?? []) console.log('   exact region ', fmt(g))
  for (const g of r.noiseARegions ?? []) console.log('   noiseA region', fmt(g))
  for (const g of r.noiseBRegions ?? []) console.log('   noiseB region', fmt(g))
}
