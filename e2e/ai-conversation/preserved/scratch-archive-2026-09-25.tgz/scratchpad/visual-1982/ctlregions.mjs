import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
const require = createRequire('/home/user/DecisionGuideAI/.claude/worktrees/agent-a7e8597930bafc021/package.json')
const { PNG } = require('pngjs')
const R = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982/raw'
for (const k of ['model-tab--1440x900--r0', 'olumi-tab--1440x900--r0']) {
  const F = PNG.sync.read(readFileSync(`${R}/A-forced/${k}.png`))
  const B = PNG.sync.read(readFileSync(`${R}/B/${k}.png`))
  let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1, n = 0
  const cols = new Map()
  for (let y = 0; y < F.height; y++) for (let x = 0; x < F.width; x++) {
    const i = (y * F.width + x) * 4
    if (F.data[i] !== B.data[i] || F.data[i + 1] !== B.data[i + 1] || F.data[i + 2] !== B.data[i + 2]) {
      n++; x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y)
      const bucket = `${Math.floor(x / 50) * 50}-${Math.floor(y / 100) * 100}`
      cols.set(bucket, (cols.get(bucket) ?? 0) + 1)
    }
  }
  console.log(k, 'exact', n, `bbox x${x0}-${x1} y${y0}-${y1}`)
  console.log('  top buckets (x-y: px):', [...cols.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k2, v]) => `${k2}:${v}`).join('  '))
  // sample a pixel inside the densest bucket
}
