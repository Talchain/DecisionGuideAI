import { defineConfig, devices } from '@playwright/test'

/**
 * THROWAWAY, UNTRACKED — PR #1982 visual adjudication only. Never committed.
 *
 * A copy of `playwright.visual.config.ts` with exactly these differences:
 *   - its own free port (5391), so it cannot collide with a sibling lane;
 *   - `executablePath` from PW_CHROMIUM_PATH (no `playwright install`);
 *   - a local capture spec that WRITES raw PNGs (no reference comparison, no
 *     bless, `e2e/visual/references/` is never touched);
 *   - no completeness teardown (this run captures a subset on purpose).
 * The identity assertion (globalSetup) and the hermetic webServer env are kept.
 */

const UNREACHABLE = 'http://127.0.0.1:9'
const PORT = 5391

export default defineConfig({
  testDir: 'e2e/visual-1982-local',
  globalSetup: './e2e/visual/globalSetup.ts',
  testMatch: '**/*.local.spec.ts',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  updateSnapshots: 'none',
  reporter: [['list']],
  timeout: 120_000,
  expect: { timeout: 20_000 },
  outputDir: 'test-results/visual-1982-local',

  use: {
    baseURL: `http://localhost:${PORT}`,
    headless: true,
    trace: 'off',
    video: 'off',
    screenshot: 'off',
    deviceScaleFactor: 1,
    launchOptions: process.env.PW_CHROMIUM_PATH ? { executablePath: process.env.PW_CHROMIUM_PATH } : {},
  },

  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        deviceScaleFactor: 1,
        launchOptions: process.env.PW_CHROMIUM_PATH ? { executablePath: process.env.PW_CHROMIUM_PATH } : {},
      },
    },
  ],

  webServer: {
    command: `pnpm exec vite --port ${PORT} --strictPort`,
    port: PORT,
    reuseExistingServer: false,
    timeout: 240_000,
    env: {
      ENGINE_SERVICE_URL: UNREACHABLE,
      CEE_SERVICE_URL: UNREACHABLE,
      ISL_SERVICE_URL: UNREACHABLE,
      PLOT_API_URL: UNREACHABLE,
      ASSIST_BFF_URL: UNREACHABLE,
      VITE_SUPABASE_URL: 'http://localhost:54321',
      VITE_SUPABASE_ANON_KEY: 'test_anon_key',
      VITE_FEATURE_SSE: '0',
      VITE_FEATURE_PRE_ANALYSIS_V3: '1',
      TZ: 'UTC',
    },
  },
})
