/**
 * THROWAWAY, UNTRACKED — PR #1982 visual adjudication only. Never committed.
 *
 * Replays the exact steps of `e2e/visual/states.visual.spec.ts` for the
 * fresh-draft / model-tab / olumi-tab (+ blocked-provisional, for context)
 * states, through the SAME harness helpers (preparePage, openCanvas,
 * seedStarterDraft, clearNotifications, freezeMotion, waitForVisualQuiescence)
 * and the same clip targets — but instead of `toHaveScreenshot` against the
 * committed references it WRITES the raw capture to OUT_DIR, plus a JSON of DOM
 * facts (dock text, control enabled-state, node geometry, readiness store) read
 * AFTER the shutter so the probe cannot perturb the pixels.
 */
import { test, expect, type Page } from '@playwright/test'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import {
  VIEWPORTS,
  clearNotifications,
  freezeMotion,
  openCanvas,
  preparePage,
  seedStarterDraft,
  waitForVisualQuiescence,
} from '../visual/harness'

const OUT_DIR = process.env.VIS1982_OUT
if (!OUT_DIR) throw new Error('VIS1982_OUT must be set')
mkdirSync(OUT_DIR, { recursive: true })

const STARTER = 'build-vs-buy' as const

async function stableShot(page: Page, clip: string | null): Promise<Buffer> {
  const opts = { animations: 'disabled' as const, caret: 'hide' as const, scale: 'css' as const }
  let prev: Buffer | null = null
  for (let i = 0; i < 10; i++) {
    const buf = clip ? await page.locator(clip).first().screenshot(opts) : await page.screenshot({ ...opts, fullPage: false })
    if (prev && prev.equals(buf)) return buf
    prev = buf
  }
  throw new Error('screenshot never stabilised across 10 consecutive captures')
}

async function domFacts(page: Page) {
  return page.evaluate(async () => {
    const vis = (el: Element) => {
      const r = el.getBoundingClientRect()
      const cs = getComputedStyle(el)
      return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'
    }
    const dock = document.querySelector('[data-testid="outputs-dock"]') as HTMLElement | null
    const buttons = [...document.querySelectorAll('button, [role="button"]')]
      .filter(vis)
      .map((b) => {
        const r = b.getBoundingClientRect()
        return {
          testid: b.getAttribute('data-testid'),
          aria: b.getAttribute('aria-label'),
          text: (b.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80),
          disabled: (b as HTMLButtonElement).disabled === true,
          ariaDisabled: b.getAttribute('aria-disabled'),
          title: b.getAttribute('title'),
          inDock: !!dock && dock.contains(b),
          box: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)],
        }
      })
    const nodes = [...document.querySelectorAll('.react-flow__node')].map((n) => {
      const r = n.getBoundingClientRect()
      return {
        id: n.getAttribute('data-id'),
        box: [Math.round(r.x * 10) / 10, Math.round(r.y * 10) / 10, Math.round(r.width * 10) / 10, Math.round(r.height * 10) / 10],
        text: (n.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120),
      }
    })
    const vp = document.querySelector('.react-flow__viewport') as HTMLElement | null
    const testids = [...document.querySelectorAll('[data-testid]')]
      .filter(vis)
      .map((e) => e.getAttribute('data-testid'))
    const footer = document.querySelector('[data-testid="pre-analysis-v3-footer"]') as HTMLElement | null
    // Read-only probe of the readiness store — same module instance via Vite's graph.
    let readiness: unknown = null
    try {
      const p = '/src/canvas/stores/readinessStore.ts'
      const m = (await import(/* @vite-ignore */ p)) as { useReadinessStore: { getState: () => Record<string, unknown> } }
      const s = m.useReadinessStore.getState()
      const r = s.readiness as Record<string, unknown> | null
      readiness = {
        readiness: r ? { can_run_analysis: r.can_run_analysis, confidence_explanation: r.confidence_explanation } : null,
        verdictAtMs: s.verdictAtMs,
        stale: s.stale,
        error: s.error,
        loading: s.loading,
      }
    } catch (e) {
      readiness = { probeError: String(e) }
    }
    return {
      dockText: dock?.innerText ?? null,
      dockBox: dock ? (() => { const r = dock.getBoundingClientRect(); return [r.x, r.y, r.width, r.height] })() : null,
      footerText: footer?.innerText ?? null,
      bodyText: document.body.innerText,
      buttons,
      nodes,
      viewportTransform: vp?.style.transform ?? null,
      testids,
      readiness,
    }
  })
}

for (const vp of VIEWPORTS) {
  test.describe(`@ ${vp.name}`, () => {
    const cases: Array<{
      name: string
      clip: string | null
      anchors: string[]
      tab?: { testid: string; label: string }
    }> = [
      {
        name: 'fresh-draft',
        clip: null,
        anchors: ['[data-testid="rf-root"]', '[data-testid="outputs-dock"]', '.react-flow__node'],
      },
      {
        name: 'blocked-provisional',
        clip: '[data-testid="outputs-dock"]',
        anchors: [
          '[data-testid="outputs-dock"]',
          '[data-testid="pre-analysis-v3"]',
          '[data-testid="pre-analysis-v3-footer"]',
          '[data-testid="pre-analysis-v3-analyse"]',
        ],
      },
      {
        name: 'model-tab',
        clip: '[data-testid="outputs-dock"]',
        anchors: ['[data-testid="outputs-dock"]', '[data-testid="model-tab"]'],
        tab: { testid: 'outputs-dock-tab-diagnostics', label: 'Model' },
      },
      {
        name: 'olumi-tab',
        clip: '[data-testid="outputs-dock"]',
        anchors: ['[data-testid="outputs-dock"]', '[data-testid="olumi-tab-wrapper"]'],
        tab: { testid: 'outputs-dock-tab-olumi', label: 'Olumi' },
      },
    ]

    for (const c of cases) {
      test(`${c.name} [${vp.name}]`, async ({ page }, testInfo) => {
        const requests: string[] = []
        page.on('request', (r) => requests.push(`${r.method()} ${r.url()}`))
        const failed: string[] = []
        page.on('requestfailed', (r) => failed.push(`${r.method()} ${r.url()} :: ${r.failure()?.errorText}`))
        const responses: string[] = []
        page.on('response', (r) => {
          const u = r.url()
          if (/\/(bff|api)\//.test(u)) responses.push(`${r.status()} ${r.request().method()} ${u}`)
        })

        await preparePage(page, vp)
        await openCanvas(page)
        const seeded = await seedStarterDraft(page, STARTER)
        expect(seeded.nodeCount).toBe(19)
        await clearNotifications(page)

        // CONTROL (opt-in): wait for the readiness check to fail, then put the
        // store into exactly the state #1982's publishCheckFailure publishes
        // (drop a LOCAL verdict — verdictAtMs null — keep error/stale). Run at
        // the merge-base, this asks: do the unchanged renderers, fed #1982's
        // store state, produce #1982's pixels?
        if (process.env.VIS1982_FORCE_NULL === '1') {
          const forced = await page.evaluate(async () => {
            const p = '/src/canvas/stores/readinessStore.ts'
            const m = (await import(/* @vite-ignore */ p)) as {
              useReadinessStore: { getState: () => Record<string, unknown>; setState: (s: Record<string, unknown>) => void }
            }
            for (let i = 0; i < 400; i++) {
              const s = m.useReadinessStore.getState()
              if (s.error && !s.loading) break
              await new Promise((r) => setTimeout(r, 25))
            }
            const before = m.useReadinessStore.getState()
            const local = before.readiness !== null && before.verdictAtMs === null
            if (local) m.useReadinessStore.setState({ readiness: null })
            return { local, error: before.error, stale: before.stale }
          })
          expect(forced.local, 'control precondition: the retained verdict must be the LOCAL one').toBe(true)
          expect(String(forced.error)).toMatch(/HTTP 503/)
        }

        if (c.tab) {
          const tab = page.getByTestId(c.tab.testid)
          await expect(tab).toBeVisible({ timeout: 20_000 })
          await expect(tab).toContainText(c.tab.label)
          await tab.click()
        }

        for (const a of c.anchors) {
          await expect(page.locator(a).first()).toBeVisible({ timeout: 20_000 })
        }
        await freezeMotion(page)
        await waitForVisualQuiescence(page)

        const buf = await stableShot(page, c.clip)
        const tag = `${c.name}--${vp.name}--r${testInfo.repeatEachIndex}`
        writeFileSync(join(OUT_DIR, `${tag}.png`), buf)

        const facts = await domFacts(page)
        writeFileSync(
          join(OUT_DIR, `${tag}.json`),
          JSON.stringify({ state: c.name, viewport: vp.name, seeded, facts, requests, failed, responses }, null, 2),
        )
      })
    }
  })
}
