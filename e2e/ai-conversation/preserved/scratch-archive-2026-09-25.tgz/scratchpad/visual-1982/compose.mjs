// Compose labelled A|B, diff and crop PNGs for PR #1982 from the raw captures.
// Rendering is done by local headless Chromium over data: URIs — no network.
import { createRequire } from 'node:module'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

const WT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-a7e8597930bafc021'
const require = createRequire(join(WT, 'package.json'))
const { PNG } = require('pngjs')
const { chromium } = require('@playwright/test')

const ROOT = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982'
const OUT = ROOT // final images live directly in visual-1982/
const summary = JSON.parse(readFileSync(join(ROOT, 'work', 'summary.json'), 'utf8'))

const A_LABEL = 'A — merge-base 820aeed1 (without #1982)'
const B_LABEL = 'B — #1982 head 6736693d'

const WHAT = {
  'fresh-draft': 'Full viewport. Dock on the Reasoning tab. Graph area: 0 differing pixels (exact).',
  'model-tab': 'Dock clip, Model tab. Only the bottom ReanalyseBar strip differs above threshold.',
  'olumi-tab': 'Dock clip, Olumi tab. Only the readiness bar (headline + Analyse first pass) differs above threshold.',
}

const png = (p) => PNG.sync.read(readFileSync(p))
const uri = (img) => 'data:image/png;base64,' + PNG.sync.write(img).toString('base64')
function crop(img, x, y, w, h) {
  const out = new PNG({ width: w, height: h })
  PNG.bitblt(img, out, x, y, w, h, 0, 0)
  return out
}
function cropBox(key, img) {
  const rs = summary[key].pmRegions
  let x0 = Infinity, y0 = Infinity, x1 = -1, y1 = -1
  for (const r of rs) { x0 = Math.min(x0, r.x); y0 = Math.min(y0, r.y); x1 = Math.max(x1, r.x + r.w); y1 = Math.max(y1, r.y + r.h) }
  const full = img.width === 416 // dock-clipped state: take the whole dock width
  const pad = full ? 30 : 14 // dock strips: enough context to read the whole bar
  const bx = full ? 0 : Math.max(0, x0 - pad)
  const by = Math.max(0, y0 - pad)
  const bw = full ? img.width : Math.min(img.width, x1 + pad) - bx
  const bh = Math.min(img.height, y1 + pad) - by
  return { x: bx, y: by, w: bw, h: bh }
}

const CSS = `
  body{margin:0;background:#fff;font:13px/1.35 "DejaVu Sans",sans-serif;color:#111}
  .wrap{display:inline-block;padding:14px}
  h1{font-size:15px;margin:0 0 4px}
  .sub{color:#444;margin:0 0 10px;max-width:1900px}
  .row{display:flex;gap:16px;align-items:flex-start}
  .col{display:flex;flex-direction:column;gap:4px}
  .lab{font-weight:bold;font-size:13px}
  .a{color:#1d4ed8}.b{color:#b45309}
  img{display:block;border:1px solid #999}
  .px{image-rendering:pixelated}
`
async function render(page, html, file) {
  await page.setContent(`<!doctype html><html><head><style>${CSS}</style></head><body><div class="wrap" id="w">${html}</div></body></html>`)
  await page.evaluate(() => Promise.all([...document.images].map((i) => i.decode())))
  await page.locator('#w').screenshot({ path: file })
}

const browser = await chromium.launch({ executablePath: process.env.PW_CHROMIUM_PATH || '/opt/pw-browsers/chromium' })
const page = await browser.newPage({ viewport: { width: 3200, height: 1200 }, deviceScaleFactor: 1 })
// Belt and braces: this page may load nothing but data: URIs.
await page.route('**/*', (r) => (r.request().url().startsWith('data:') ? r.fallback() : r.abort()))

const written = []
for (const key of Object.keys(summary)) {
  const [state, vp] = key.split('--')
  const s = summary[key]
  const A = png(join(ROOT, 'raw/A', `${key}--r0.png`))
  const B = png(join(ROOT, 'raw/B', `${key}--r0.png`))
  const D = png(join(ROOT, 'work', `${key}--diff.png`))
  const stats = `pixelmatch threshold 0.2 (the harness's own): A↔B ${s.AvsB.pm} px (exact ${s.AvsB.exact}); noise A↔A ${s.noiseA.pm} px, B↔B ${s.noiseB.pm} px (two captures per head, same machine).`
  const base = `12-readiness-1982-${state}-${vp}`

  await render(page, `
    <h1>PR #1982 · ${state} · ${vp}</h1><p class="sub">${WHAT[state]}<br>${stats}</p>
    <div class="row">
      <div class="col"><span class="lab a">${A_LABEL}</span><img src="${uri(A)}"></div>
      <div class="col"><span class="lab b">${B_LABEL}</span><img src="${uri(B)}"></div>
    </div>`, join(OUT, `${base}-AB.png`))

  await render(page, `
    <h1>PR #1982 · ${state} · ${vp} · pixel diff A↔B</h1>
    <p class="sub">Red = differs above pixelmatch threshold 0.2; yellow = anti-aliasing only; faded = identical. ${stats}</p>
    <img src="${uri(D)}">`, join(OUT, `${base}-diff.png`))

  const box = cropBox(key, A)
  const scale = A.width === 416 ? 2 : 1
  const cA = crop(A, box.x, box.y, box.w, box.h)
  const cB = crop(B, box.x, box.y, box.w, box.h)
  const stacked = scale === 2
  const imgA = `<img class="px" width="${box.w * scale}" src="${uri(cA)}">`
  const imgB = `<img class="px" width="${box.w * scale}" src="${uri(cB)}">`
  await render(page, `
    <h1>PR #1982 · ${state} · ${vp} · changed region (x${box.x} y${box.y} ${box.w}×${box.h}${scale > 1 ? ', shown at 2×' : ''})</h1>
    <p class="sub">Union of every region that differs above threshold, padded for context.</p>
    <div class="${stacked ? 'col' : 'row'}" style="gap:14px">
      <div class="col"><span class="lab a">${A_LABEL}</span>${imgA}</div>
      <div class="col"><span class="lab b">${B_LABEL}</span>${imgB}</div>
    </div>`, join(OUT, `${base}-crop.png`))
  written.push(`${base}-AB.png`, `${base}-diff.png`, `${base}-crop.png`)
}
await browser.close()
console.log(written.join('\n'))
