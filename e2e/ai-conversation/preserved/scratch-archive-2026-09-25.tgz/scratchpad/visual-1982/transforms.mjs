import { readFileSync, existsSync } from 'node:fs'
const R = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982/raw'
for (const st of ['fresh-draft', 'model-tab', 'olumi-tab']) for (const vp of ['1440x900', '1280x800']) {
  const row = []
  for (const [s, r] of [['A', 0], ['A', 1], ['B', 0], ['B', 1], ['A-forced', 0]]) {
    const p = `${R}/${s}/${st}--${vp}--r${r}.json`
    if (!existsSync(p)) continue
    const t = JSON.parse(readFileSync(p, 'utf8')).facts.viewportTransform
    row.push(`${s}r${r}=${t.includes('0.511838') ? 'fit-0.5118' : t.includes('scale(0.5)') ? 'fit-0.5' : t}`)
  }
  console.log(`${st} ${vp}`.padEnd(22), row.join('  '))
}
