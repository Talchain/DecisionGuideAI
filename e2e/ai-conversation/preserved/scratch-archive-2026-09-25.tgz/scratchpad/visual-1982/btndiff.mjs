import { readFileSync } from 'node:fs'
const R = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982/raw'
const load = (s, k) => JSON.parse(readFileSync(`${R}/${s}/${k}.json`, 'utf8')).facts
for (const k of ['model-tab--1440x900--r0', 'olumi-tab--1440x900--r0', 'model-tab--1440x900--r1']) {
  const pairs = k.endsWith('r1') ? [['A', 'B']] : [['A-forced', 'B'], ['A', 'B']]
  for (const [x, y] of pairs) {
    const f = load(x, k), b = load(y, k)
    const diffBtns = f.buttons.filter((bt, i) => JSON.stringify(bt) !== JSON.stringify(b.buttons[i]))
    console.log(k, `${x} vs ${y}`, '| rf transform', f.viewportTransform, 'vs', b.viewportTransform,
      '| nodes', JSON.stringify(f.nodes) === JSON.stringify(b.nodes) ? 'same' : 'DIFFER',
      '| differing buttons', diffBtns.length, 'inDock', diffBtns.filter((d) => d.inDock).length,
      '| testids', [...new Set(diffBtns.map((d) => (d.testid || '').replace(/-[a-z]+_.*/, '-*')))].join(','))
  }
}
