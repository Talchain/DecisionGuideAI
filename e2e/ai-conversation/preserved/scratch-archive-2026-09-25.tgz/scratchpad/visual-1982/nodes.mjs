// Structural A-vs-B comparison of everything OUTSIDE the dock.
import { readFileSync } from 'node:fs'
const R = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982/raw'
for (const vp of ['1440x900', '1280x800']) for (const st of ['fresh-draft', 'model-tab', 'olumi-tab']) {
  const a = JSON.parse(readFileSync(`${R}/A/${st}--${vp}--r0.json`, 'utf8')).facts
  const b = JSON.parse(readFileSync(`${R}/B/${st}--${vp}--r0.json`, 'utf8')).facts
  const nodesSame = JSON.stringify(a.nodes) === JSON.stringify(b.nodes)
  const vpSame = a.viewportTransform === b.viewportTransform
  const nonDock = (f) => JSON.stringify(f.buttons.filter((x) => !x.inDock))
  const nonDockSame = nonDock(a) === nonDock(b)
  const strip = (f) => f.bodyText.replace(f.dockText, '<DOCK>')
  const outsideSame = strip(a) === strip(b)
  const tA = new Set(a.testids), tB = new Set(b.testids)
  const onlyA = [...tA].filter((x) => !tB.has(x)), onlyB = [...tB].filter((x) => !tA.has(x))
  console.log(vp, st, '| nodes', a.nodes.length, nodesSame ? 'IDENTICAL' : 'DIFFER',
    '| rf transform', vpSame ? `same (${a.viewportTransform})` : `A=${a.viewportTransform} B=${b.viewportTransform}`,
    '| non-dock buttons', nonDockSame ? 'same' : 'DIFFER',
    '| body text outside dock', outsideSame ? 'same' : 'DIFFER')
  console.log('   testids only in A:', JSON.stringify(onlyA), ' only in B:', JSON.stringify(onlyB))
}
