// Control: A (merge-base renderers) with the store forced to #1982's state, vs B.
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
const require = createRequire('/home/user/DecisionGuideAI/.claude/worktrees/agent-a7e8597930bafc021/package.json')
const { PNG } = require('pngjs')
const pixelmatch = require('pixelmatch')
const ROOT = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/visual-1982/raw'
for (const st of ['fresh-draft', 'model-tab', 'olumi-tab']) for (const vp of ['1440x900', '1280x800']) {
  const k = `${st}--${vp}--r0`
  const F = PNG.sync.read(readFileSync(join(ROOT, 'A-forced', `${k}.png`)))
  const B = PNG.sync.read(readFileSync(join(ROOT, 'B', `${k}.png`)))
  if (F.width !== B.width || F.height !== B.height) { console.log(k, 'SIZE MISMATCH'); continue }
  const pm = pixelmatch(F.data, B.data, null, F.width, F.height, { threshold: 0.2 })
  let exact = 0, md = 0
  for (let i = 0; i < F.data.length; i += 4) {
    const d = Math.max(Math.abs(F.data[i] - B.data[i]), Math.abs(F.data[i + 1] - B.data[i + 1]), Math.abs(F.data[i + 2] - B.data[i + 2]))
    if (d || F.data[i + 3] !== B.data[i + 3]) exact++
    md = Math.max(md, d)
  }
  const fF = JSON.parse(readFileSync(join(ROOT, 'A-forced', `${k}.json`), 'utf8')).facts
  const fB = JSON.parse(readFileSync(join(ROOT, 'B', `${k}.json`), 'utf8')).facts
  console.log(k.padEnd(26), `A-forced vs B: pixelmatch ${pm} px, exact ${exact} px, max channel delta ${md}`,
    '| dockText', fF.dockText === fB.dockText ? 'same' : 'DIFFER',
    '| buttons', JSON.stringify(fF.buttons) === JSON.stringify(fB.buttons) ? 'same' : 'DIFFER',
    '| store', JSON.stringify(fF.readiness) === JSON.stringify(fB.readiness) ? 'same' : `DIFFER ${JSON.stringify(fF.readiness)}`)
}
