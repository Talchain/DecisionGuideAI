# AI Conversation rows for Paul's guide (RC owns the guide). Chat after a Run.

**SERVED 09:16:52Z:** UI `940bf15d` = `b017e3c2` + #2004 (no win-% ranking under a withheld leader). CEE train I `7131445`.
**Expected build (original):** UI = U2 `580d135b` (#1983, #1968, #1981, #1980, #1987) + U3b (#1997: the flip #1992, bundle 3 #1993, #1994) if it lands before 06:00Z. CEE as RC states.
**NOT in the build:** G1 #1985 (a card action stays taken after a reload). It is APPROVED at `8a4dbc4e` and rides U4 after 09:00Z. #1982 (readiness outage) has no verdict yet.
**Verify before posting:** `version.json` on the served UI = __UI_SHA__, checked at __TIME__Z.

| Step | Do | Expect | Fix |
|---|---|---|---|
| 1 | Pricing brief; wait for the first reply | The reply opens at its first sentence (not scrolled to the end). No "Model changed" on the automatic first pass. The consent turn shows its consent buttons; the run card stays a collapsed line on that turn | #1981, #1983, flip |
| 2 | Approve, then Run | The conclusion is in view when the reply lands. The run card's one action is on the face and live. The first-pass card reads "Written about an earlier run of this model…" with its action disabled. **When the reply says no option can be put forward, the Analysis result card shows NO win-% list** (the numbers stay in the reply's own prose) | #1981, flip, #1968, **#2004 (served 09:16Z)** |
| 3 | Click the card's action | The button settles at once; no "Sent" badge. One reply follows and names no leader | #1961 |
| 4 | Reload | The clicked card's action is disabled, and the card reads "Olumi can't confirm this still matches your latest analysis." (currency is unknown after a reload). The first-pass card may now show its line on the face, also disabled: a known layout shift | #1968, flip `unknown` |
| 5 | Ask one more question (e.g. "What should I check first?") | **KNOWN GAP until G1 lands:** once the reply restates the analysis, the card you clicked in step 3 turns live again. Don't click it twice: that sends a duplicate turn. With G1 it would stay settled | G1 #1985, after 09:00Z |

**Report back:** the first step whose page differs from "Expect".
