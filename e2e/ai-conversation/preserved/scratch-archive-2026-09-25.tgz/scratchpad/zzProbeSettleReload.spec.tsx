/**
 * THROWAWAY PROBE — never committed. Measures whether (a) a clicked coaching
 * chip and (b) a settled held proposal survive a REAL reload of the panel
 * (transcriptStore save -> fresh ConversationProvider -> mount restore).
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, fireEvent, waitFor, cleanup } from '@testing-library/react'

vi.mock('../turnService', () => ({
  callOrchestratorTurn: () => new Promise(() => {}),
  streamOrchestratorTurn: async function* () { /* never yields */ },
  OrchestratorError: class extends Error {},
}))
const v5Calls: unknown[] = []
vi.mock('../../../v5/v5Adapter', () => ({
  callV5Turn: (...args: unknown[]) => { v5Calls.push(args); return new Promise(() => {}) },
  getV5Endpoint: () => 'https://example.invalid/v5/turn',
}))

import { OlumiTabBody } from '../../components/OlumiTabBody'
import { ConversationProvider } from '../ConversationContext'
import { useCanvasStore } from '../../store'
import { saveTranscript, TRANSCRIPT_STORAGE_KEY } from '../utils/transcriptStore'
import type { ConversationMessage, ConversationBlock } from '../types'

const SID = '561548c3-acd6-4488-b088-399c7cc15631'
const HASH = 'abcdef0123456789'

const coaching = {
  type: 'v5_coaching',
  block_id: 'coach-1',
  title: 'Check an assumption',
  body: 'Body',
  coaching_kind: 'assumption_check',
  source: 'decision_review',
  target_refs: [],
  freshness: 'fresh',
  action_label: 'Check it',
  action_prompt: 'Please check the assumption.',
  graph_hash_at_generation: HASH,
} as unknown as ConversationBlock

const held = {
  type: 'v5_held_proposal',
  proposal_id: 'gmh_aaaa1111',
  summary: 'Remove X',
  mutation_class: 'structural',
  reason_code: 'REMOVE_UNCONFIRMED',
  confirm: { label: 'Confirm these changes', message: 'confirm gmh_aaaa1111' },
} as unknown as ConversationBlock

function prior(): ConversationMessage[] {
  return [
    { id: 'u1', role: 'user', content: 'brief', timestamp: new Date('2026-07-25T17:38:01Z') },
    { id: 'a-coach', role: 'assistant', content: 'coach turn', blocks: [coaching], timestamp: new Date('2026-07-25T17:39:10Z') },
    { id: 'a-held', role: 'assistant', content: 'held turn', blocks: [held], timestamp: new Date('2026-07-25T17:40:10Z') },
  ]
}

function restampAsEarlierPageLoad() {
  const file = JSON.parse(localStorage.getItem(TRANSCRIPT_STORAGE_KEY)!)
  file[SID].pageLoadId = 'an-earlier-page-load'
  localStorage.setItem(TRANSCRIPT_STORAGE_KEY, JSON.stringify(file))
}

function mount() {
  return render(
    <ConversationProvider>
      <OlumiTabBody />
    </ConversationProvider>,
  )
}

describe('PROBE', () => {
  beforeEach(() => {
    localStorage.clear()
    v5Calls.length = 0
    useCanvasStore.setState({
      currentScenarioId: null,
      analysisFreshness: { freshness: 'fresh', currentGraphHash: HASH },
      analysisFreshnessDirty: false,
    } as never)
    if (!Element.prototype.scrollIntoView) Element.prototype.scrollIntoView = () => {}
    vi.spyOn(Element.prototype, 'scrollIntoView').mockImplementation(() => {})
  })

  it('reload after settling: what comes back?', async () => {
    saveTranscript(SID, prior())
    restampAsEarlierPageLoad()
    useCanvasStore.setState({ currentScenarioId: SID })

    const first = mount()
    const q = (id: string) => first.container.querySelector<HTMLButtonElement>(`[data-testid="${id}"]`)
    await waitFor(() => expect(q('v5-held-proposal-confirm')).not.toBeNull())
    // open any collapsed detail
    first.container.querySelectorAll<HTMLElement>('[data-testid="block-detail-toggle"]').forEach((b) => fireEvent.click(b))
    await waitFor(() => expect(q('v5-coaching-action')).not.toBeNull())

    fireEvent.click(q('v5-coaching-action')!)
    fireEvent.click(q('v5-held-proposal-confirm')!)
    await waitFor(() => expect(q('v5-coaching-action')!.getAttribute('data-settled')).toBe('true'))
    await waitFor(() => expect(q('v5-held-proposal-confirm')).toBeNull())
    const sendsBeforeReload = v5Calls.length
    // eslint-disable-next-line no-console
    console.log('PROBE sends before reload:', sendsBeforeReload)
    // eslint-disable-next-line no-console
    console.log('PROBE stored keys for scenario:', Object.keys(JSON.parse(localStorage.getItem(TRANSCRIPT_STORAGE_KEY)!)[SID]))

    first.unmount()
    cleanup()
    restampAsEarlierPageLoad()

    const second = mount()
    const q2 = (id: string) => second.container.querySelector<HTMLButtonElement>(`[data-testid="${id}"]`)
    await waitFor(() => expect(second.container.querySelector('[data-testid="v5-held-proposal"]')).not.toBeNull())
    second.container.querySelectorAll<HTMLElement>('[data-testid="block-detail-toggle"]').forEach((b) => fireEvent.click(b))
    await waitFor(() => expect(q2('v5-coaching-action')).not.toBeNull())

    const chip = q2('v5-coaching-action')!
    const confirm = q2('v5-held-proposal-confirm')
    // eslint-disable-next-line no-console
    console.log('PROBE after reload — chip disabled:', chip.disabled, 'settled attr:', chip.getAttribute('data-settled'))
    // eslint-disable-next-line no-console
    console.log('PROBE after reload — held confirm button present:', confirm !== null, 'disabled:', confirm?.disabled)
    fireEvent.click(chip)
    await new Promise((r) => setTimeout(r, 50))
    // eslint-disable-next-line no-console
    console.log('PROBE sends after reload + one click on the restored chip:', v5Calls.length)
  })
})
