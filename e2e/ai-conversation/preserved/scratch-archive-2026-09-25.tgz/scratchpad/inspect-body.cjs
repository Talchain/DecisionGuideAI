const path = process.argv[2];
const b = require(path);
const t2 = require('/home/user/cee-prb-wt/src/orchestrator-v5/coaching/__tests__/fixtures/c19-8428207-B.run-turns.trimmed.json').turns.t2;
console.log('top keys:', Object.keys(b));
const ar = (b.blocks || []).find((x) => x.type === 'analysis_result');
const diff = (a, c, p = '') => {
  if (JSON.stringify(a) === JSON.stringify(c)) return;
  if (a && c && typeof a === 'object' && typeof c === 'object' && !Array.isArray(a)) {
    for (const k of new Set([...Object.keys(a), ...Object.keys(c)])) diff(a[k], c[k], `${p}.${k}`);
  } else console.log('DIFF', p, '\n  body:', JSON.stringify(a)?.slice(0, 400), '\n  t2  :', JSON.stringify(c)?.slice(0, 400));
};
diff(ar, t2.analysis_result, 'analysis_result');
diff(b.analysis_state, t2.analysis_state, 'analysis_state');
diff(b.analysis_ready, t2.analysis_ready, 'analysis_ready');
console.log('draft_graph', JSON.stringify(b.draft_graph).slice(0, 300));
console.log('stage', b.stage_indicator, 'insights', JSON.stringify(b.insights));
console.log('_answer_shape', JSON.stringify(b._answer_shape));
console.log('_agent', JSON.stringify(b._agent).slice(0, 500));
const card = (b.blocks || []).find((x) => x.type === 'coaching');
console.log('card', JSON.stringify(card, null, 1));
