**Risk: NOT LOW** (conversation send path and transcript persistence). Lease: GRANTED on #63 (5824401606, extension 5824744004 §3, re-confirmed 5824943566 §2).

## What the user gets
A card action the user already took **stays taken after a reload**. Before this change, a coaching chip's "settled" state was component state, and a held proposal's Confirm was settled only in in-memory `patchBlockStates`. After a reload both came back live, and one more click sent a second turn (a duplicate action).

## The rule
A card action is settled if and only if a **delivered** user message created by that action exists in the saved transcript.
- **Scope:** coaching chips and held-proposal Confirm.
- **Keys:** the message carries `sourceBlockKey`: `coach:<turnId>:<block_id>` or `held:<turnId>:<proposal_id>`.
- **Which sends count:** the transcript store already drops `failed` and `pending` sends, so a send that never went out leaves its card live.
- **One rule, not two:** `settledSourceBlockKeys()` is built on the store's own `isPersistable` rule. The live answer and the post-reload answer therefore cannot drift apart.
- **Per-turn scoping:** keys include the turn id. The same `block_id` or hold handle re-issued on a later turn is a new offer and stays live.
- **UI-only:** the key never reaches the wire. It rides beside the chip metadata and is stamped on the bubble. Spec (h) pins that the POSTed body is byte-identical with and without the key.
- **`unconfirmed` sends:** these are kept by the store, so their card reads settled with no duplicate action. The card makes no success claim, per RC 5824744004 §3.

## Changes
| File | Change |
|---|---|
| `utils/transcriptStore.ts` | Persists `sourceBlockKey` (optional, so older saves load unchanged); adds `settledSourceBlockKeys()` and the two key builders |
| `useConversation.ts` | Carries the key `sendChip` → `dispatchAction` → `sendTurn` → user bubble. Exposes `settledSourceBlockKeys`. Seeds restored `held:` keys into the ONE held registry (layout effect, missing entries only) |
| `ActionChip.tsx` | Settled = local state OR a transcript key (via the optional conversation context). Sends its key in the meta |
| `V5CoachingBlock.tsx` / `InlineBlocks.tsx` | Pass `turnId` so the card can build its key |
| `ConversationPanel.tsx` | **1 line:** the registered `_sendChip` seam forwards `meta.sourceBlockKey` onto the chip |
| `guidanceStore.ts` | Type only: `SendChipMeta.sourceBlockKey` |
| `V5HeldProposalBlock.tsx` | `handleConfirm` sends its `held:` key beside the producer's `action_type`. The confirm message is unchanged |
| Specs | New `cardActionSettledReload.spec.tsx` (20). The 2 expectations in `heldProposalSettlement.crossSurface.spec`. 7 typed stubs gain the new return field |

## Tests (jsdom + localStorage; mocked network runner; NO model calls)
`cardActionSettledReload.spec.tsx` covers:
- the key shapes;
- layer 1 (card → meta);
- layer 3 (bubble → save → reload, with a real `useConversation`);
- layer 4 (restored transcript → settled): (a) clicked, (b) never clicked, (c) sibling, (d) same `block_id` on another turn, (e) failed send, (f) held Confirm and a later re-issue;
- (g) a pre-G1 save;
- (h) wire bytes.

**End to end:** a real click in the mounted `OlumiTabBody` → `ConversationPanel` → delivered → reload → settled, for coaching and held. It also covers R&C's remount case (5824576658 §4): a remounted chip loses its local state but stays settled.

**Mutation checks (each turns the suite red):**
- the seam drops the key → 3 fail;
- settlement is local-only → 2 fail (coaching end to end, remount).

**Local results:** typecheck gate PASSED; ESLint 0 errors on the changed files; all 26 `src/v5/blocks` spec files (373 tests) and the G1 specs (37) green; `scripts/validate-prepush.sh` (run by hand; smoke suite, typecheck, stale-.js, dep audit) ALL CHECKS PASSED. A broad `--changed` run was stopped at 46 files (0 failures) for time; CI runs the full suite.

## Not covered
- A served browser witness. The joined witness follows RC's merge order.
- Settlement for chips other than coaching cards and held Confirm (for example suggested-action chips). They carry no key, so they behave exactly as before.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Q5bxkDMkNnEcRXKYsV9zEa
