[AI CONVERSATION → DELIVERY LEAD / RC] HANDOFF v1 — increment 1 (__TIME__)

`OWNER AI Conversation | BOUNDARY chat rendering, action controls, progressive disclosure | HEADS below | PROVEN source+jsdom+fixture-served browser; NOT TESTED live ?ai=openai | NEXT below | BLOCKER below`

**PRs**
| PR | Head | What the user gets | Independent verdict | CI |
|---|---|---|---|---|
| DGAI #1961 | `d0caf2b3` | A stale coaching card's action is disabled beside its notice. CEE's own "Re-run analysis" stays live. No false "Sent". No same-tick double send. | APPROVE 5821328591 (after CHANGES_REQUIRED 5820345625, fixed) | __1961CI__ |
| DGAI #1966 | merged `08bbbcfd` | The Run chip asks the run gate. No-command labels render as text, not dead chips. | APPROVE | merged |
| DGAI #1968 | `b94d7a9b` (stacked on #1961) | Run-turn card currency (3-part rule) with a notice naming the failed limb, on the v3 producer payload. Promotion shipped OFF. | APPROVE at `812756e5`; delta re-review in progress (pickup 5821720722) | runs after retarget. Trial merge with staging `fd64ff76`: clean; typecheck exit 0; 513/513 |
| __RUNCHIP__ |

**Files (lease)**
- #1961: `src/v5/blocks/ActionChip.tsx`, `V5CoachingBlock.tsx`, `coachingCurrency.ts`, `src/canvas/conversation/__tests__/runReplyAcceptance.spec.tsx`
- #1968: `src/v5/phase3TypedBlocks.ts`, `src/canvas/conversation/types.ts` (2 optional fields), `coachingCurrency.ts`, `useCoachingCurrency.ts`, `V5CoachingBlock.tsx`, `messageComposition.ts`, `CoachingLine.tsx`, specs and fixtures
- Lease ACKs: RC 5819307155 / 5819467504, Panel 5819268514 / 5819355965, Canvas 5819973778

**Tests**
- #1961: 34 acceptance tests on 4 captured Run turns.
  - Covers: no promotion, one verbatim send, ineligible, blocked, stale-after-edit, rerun, reload, the CEE stale-rerun control.
  - Mutation-checked.
- #1968:
  - Specs: currencyFields 37, runTurnCurrency 40, promotion 21, and the OpenAI acceptance spec on AI Quality's 57f903c captures.
  - 27 mutations, each turning a spec red.
  - `src/v5` + `src/canvas/conversation`: 5,046 green.
- No model calls anywhere: jsdom plus fixtures. CI makes no provider calls; Core E2E is skipped unless `e2e/core/**` changes.

**Served-browser witness** (local vite, fixture-served, 0 off-origin requests completed): https://github.com/Talchain/DecisionGuideAI/tree/witness/ai-conversation-local/e2e/ai-conversation/evidence
- #1961 current and moved card; #1966 Run chip; OpenAI Run replies (pricing complete, hiring blocked); #1968 in 4 states.
- NOT a live OpenAI journey: staging hosts are blocked in this container.

**Diagnosis: long OpenAI replies** (measured on 57f903c captures; to confirm on a fresh capture after copy v2)
- **Cause:** prose volume in `assistant_text` (Run 195 words, blocked 101, construction ~300). Not the typed payload and not the renderer.
- **Fix owner:** AI Quality copy v2 (5821661184), landing with #1854 B1.
- **What I ruled out:** a sidecar `_answer_shape` below 3,150 characters only hides text (see 5821918849). Withdrawn.

**Next move after a Run** = R&C's run-turn card.
- Producer: CEE #1855, APPROVED.
- Route leg: PR-B / #1854, which needs the B1 click guard.
- The UI consumer is ready (#1968). The promotion flag flip is a one-line PR, and RC's to call once the guard is served.

**Open, routed**
- Panel: the Run card says "fairly confident" while the reply says "does not establish".
- Runtime: the click guard (#1854 B1).
- __RUNCHIPOPEN__

**Paul needs to do nothing yet.** One verified test instruction follows once #1854 + #1968 are served.
