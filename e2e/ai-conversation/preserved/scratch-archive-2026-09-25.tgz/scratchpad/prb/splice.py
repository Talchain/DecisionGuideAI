import sys

spec = '/home/user/DecisionGuideAI/.claude/worktrees/agent-aa36ca5729340ad67/src/canvas/conversation/__tests__/prbRouteRunReply.acceptance.spec.tsx'
sec = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/prb/section4.tsx.txt'
lines = open(spec, encoding='utf8').read().split('\n')
start = next(i for i, l in enumerate(lines) if l.startswith('// §4'))  - 1  # the dashed line above
end = next(i for i, l in enumerate(lines) if l.startswith("describe('§5"))
assert lines[start].startswith('// ----'), lines[start]
new = lines[:start] + open(sec, encoding='utf8').read().rstrip('\n').split('\n') + [''] + lines[end:]
text = '\n'.join(new)
old_imp = "import { useReadinessStore } from '../../stores/readinessStore'"
assert old_imp in text
text = text.replace(old_imp, "import { useReadinessStore, __test__ as readinessTest } from '../../stores/readinessStore'")
open(spec, 'w', encoding='utf8').write(text)
print('spliced', start, end)
