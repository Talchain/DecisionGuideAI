/**
 * THROWAWAY (not committed to CEE) — PR-B ROUTE CAPTURE for the UI acceptance + served witness.
 *
 * The REAL `/agent/v1/turn` route, the REAL run-turn coaching builder, the REAL first-analysis
 * runner, over the product double that `first-analysis-coaching-card.test.ts` uses (same mocks,
 * same `c19-8428207-B` t2 served run fixture, same READY_GRAPH / BLOCKED_GRAPH). The model is the
 * harness's scripted fetch stub: tool calls and every reply are FIXED here. No provider, no network:
 * `prb-no-network.setup.ts` refuses every non-loopback fetch and socket, and this file asserts its
 * ledger did not move while the route ran.
 *
 * Writes the FULL HTTP response body of each turn, byte for byte as `app.inject` received it, to
 * `$PRB_OUT_DIR/$PRB_LABEL.<turn>.route-body.json`, plus a meta file.
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execSync } from 'node:child_process';

import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import Fastify, { type FastifyInstance } from 'fastify';
import { CoachingBlockSchema } from '@talchain/schemas/boundary';
import { READY_GRAPH, BLOCKED_GRAPH } from './fixtures/first-analysis-graphs.js';

type Turn = { graph_hash: string; analysis_state: Record<string, unknown>; analysis_ready: unknown; analysis_result: Record<string, unknown> };
const fixture = JSON.parse(readFileSync(new URL('../../coaching/__tests__/fixtures/c19-8428207-B.run-turns.trimmed.json', import.meta.url), 'utf8')) as { turns: Record<string, Turn> };
const T2 = fixture.turns.t2!;

const OUT_DIR = process.env.PRB_OUT_DIR ?? '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/prb';
const LABEL = process.env.PRB_LABEL ?? 'cee-unknown';

interface Scenario { registered: boolean; graph: typeof READY_GRAPH; ran: boolean; inProcessRuns: number; injectRuns: number }
const scenarios = new Map<string, Scenario>();
const st = (sid: string): Scenario => {
  let s = scenarios.get(sid);
  if (s === undefined) { s = { registered: false, graph: READY_GRAPH, ran: false, inProcessRuns: 0, injectRuns: 0 }; scenarios.set(sid, s); }
  return s;
};
let knobs: { graph: typeof READY_GRAPH; run: 'complete' | 'blocked' } = { graph: READY_GRAPH, run: 'complete' };

const { runStub } = vi.hoisted(() => ({ runStub: { impl: null as null | ((a: unknown) => Promise<unknown>) } }));
vi.mock('../../handlers/chip-click-dispatch.js', async (importOriginal) => {
  const actual = await importOriginal<Record<string, unknown>>();
  return { ...actual, dispatchChipClickRunAnalysis: (a: unknown) => runStub.impl!(a) };
});
vi.mock('../../build-turn-context.js', async (importOriginal) => {
  const actual = await importOriginal<Record<string, unknown>>();
  return { ...actual, loadPriorFactsWithReadState: async () => ({ status: 'ok', facts: [] }) };
});
const store = {
  ensureScenarioExists: vi.fn(async () => ({ user_id: null })),
  readCommittedTurn: vi.fn(async () => null),
  append: vi.fn(async () => ({ id: 'row-1' })),
};
vi.mock('../../session/index.js', () => ({ getSessionStore: () => store }));
vi.mock('../../../orchestrator/user-identity.js', async (importOriginal) => {
  const actual = await importOriginal<Record<string, unknown>>();
  return { ...actual, resolveUserIdentity: async () => ({ mode: 'off' }) };
});

const BRIEF = 'Should we raise the Pro price or grow the Pro subscriber base to lift MRR?';
const candidate = {
  goal: { metric: 'MRR', operator: '>=', value: 100, unit: 'k', horizon_months: 6, provenance: 'explicit' },
  constraints: [],
  options: [{ label: 'Raise the Pro price', provenance: 'explicit', interventions: [] }],
  factors: [{ label: 'Pro subscriber base', role: 'controllable', baseline_known: true, baseline_value: 5, unit: 'k', provenance: 'explicit' }],
  risks: [], outcomes: [{ label: 'MRR', provenance: 'inferred' }],
  links: [{ from: 'Pro subscriber base', to: 'MRR', direction: 'positive', provenance: 'inferred' }],
  unknowns: [],
};

/**
 * THE SCRIPTED INTERPRETATION of the explicit Run (the one `tool_choice: 'none'` call). Written in the
 * Interpreter v0.2 / AI Quality copy shape: finding + its caveat first, ≤3 grounded points, one next
 * step. Grounded ONLY in the t2 run: constraint verdict withheld (the churn limit was not scored),
 * leader withheld (no option named), robustness low, fragile Pro subscriber base → MRR.
 */
const RUN_REPLY = [
  '**This run can’t yet say which pricing path to take**, because the churn limit (under 4% a month) could not be scored, so none of the three options has been checked against it.',
  '',
  '- On the MRR goal alone, how often each option scored highest is a comparison inside this model, not a chance of reaching your target.',
  '- Robustness is low: the result is sensitive to several links, including how strongly the Pro subscriber base drives MRR.',
  '',
  'Next, tell me which part of the model the churn limit applies to, then run it again.',
].join('\n');
const BLOCKED_REPLY = [
  'The analysis didn’t run: Option B doesn’t change anything in the model yet, so it can’t be compared with Option A.',
  '',
  'Tell me what Option B would change — for example, its effect on Delivery reliability — and I can propose it for you to approve before running again.',
].join('\n');
const BUILD_REPLY = 'Here is a provisional first pass to argue with.';

let script: Array<Record<string, unknown>> = [];
const say = (text: string) => ({ output: [{ type: 'message', content: [{ type: 'output_text', text }] }] });
const callTool = (name: string, args: Record<string, unknown>) => ({ output: [{ type: 'function_call', name, call_id: 'c1', arguments: JSON.stringify(args) }] });

/** Every call the route made to its model, as the stub received it. */
const modelCalls: Array<{ url: string; authorization: string; tool_choice: unknown; kind: string; answered: string }> = [];
const OPENAI_URL = 'https://api.openai.com/v1/responses';

function installFetch() {
  const guarded = (globalThis as { __PRB_GUARDED_FETCH__?: typeof fetch }).__PRB_GUARDED_FETCH__;
  if (guarded === undefined) throw new Error('the PRB network guard is not installed');
  vi.stubGlobal('fetch', vi.fn(async (u: unknown, init?: { body?: string; headers?: Record<string, string> }) => {
    const url = String(u);
    // Anything but the one model endpoint the route uses goes to the GUARD, which refuses it.
    if (url !== OPENAI_URL) return guarded(u as string, init as RequestInit);
    const body = JSON.parse(String(init?.body ?? '{}')) as Record<string, unknown> & { text?: { format?: { type?: string } } };
    const authorization = String(init?.headers?.authorization ?? '');
    if (body.text?.format?.type === 'json_schema') {
      modelCalls.push({ url, authorization, tool_choice: body['tool_choice'], kind: 'construction(json_schema)', answered: 'candidate' });
      return new Response(JSON.stringify({ output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify(candidate) }] }] }), { status: 200 });
    }
    if (body['tool_choice'] === 'none') {
      const text = knobs.run === 'blocked' ? BLOCKED_REPLY : RUN_REPLY;
      modelCalls.push({ url, authorization, tool_choice: 'none', kind: 'run-interpretation', answered: knobs.run === 'blocked' ? 'BLOCKED_REPLY' : 'RUN_REPLY' });
      return new Response(JSON.stringify(say(text)), { status: 200 });
    }
    const next = script.shift();
    modelCalls.push({ url, authorization, tool_choice: body['tool_choice'], kind: 'agent-loop', answered: next === undefined ? 'BUILD_REPLY' : JSON.stringify(next).slice(0, 80) });
    return new Response(JSON.stringify(next ?? say(BUILD_REPLY)), { status: 200 });
  }));
}

function readbackOf(s: Scenario): Record<string, unknown> {
  if (!s.registered) return { graph: { nodes: [], edges: [] }, graph_hash: 'empty' };
  if (!s.ran) return { graph: s.graph, graph_hash: T2.graph_hash, analysis_state: { run_state: { kind: 'never_run' }, leader_claim: { permitted: false, withheld_reason: 'no_analysis' } } };
  return { graph: s.graph, graph_hash: T2.graph_hash, analysis_state: T2.analysis_state, analysis_result: T2.analysis_result, analysis_ready: T2.analysis_ready };
}

let blockedRunReady: unknown;
async function buildApp(): Promise<FastifyInstance> {
  vi.resetModules();
  const { agentV1TurnRoute } = await import('../../../routes/agent-v1-turn.js');
  const { buildCanonicalAnalysisReadyFromGraph } = await import('../../../orchestrator/tools/analysis-ready-helper.js');
  blockedRunReady = buildCanonicalAnalysisReadyFromGraph(BLOCKED_GRAPH as never);
  const a = Fastify({ logger: false });
  a.post('/assist/v1/scenarios/:id/graph', async (req) => readbackOf(st((req.params as { id: string }).id)));
  a.post('/assist/v1/scenarios/:id/graph/register', async (req) => {
    const s = st((req.params as { id: string }).id);
    s.registered = true;
    s.graph = knobs.graph;
    return { registered: true, graph_hash: T2.graph_hash, model_version: { version_id: '00000000-0000-4000-8000-000000000001', version_number: 1 } };
  });
  a.post('/assist/v1/scenarios/:id/versions', async () => ({ versions: [], next_cursor: null }));
  a.post('/orchestrate/v2/turn', async (req) => {
    const b = req.body as { scenario_id: string; chip?: { action_type?: string } };
    if (b.chip?.action_type === 'run_analysis') {
      const s = st(b.scenario_id);
      s.injectRuns += 1;
      if (knobs.run === 'blocked') {
        // A BLOCKED Run: HTTP 200, no analysis_result, CEE's own readiness for this graph (the real builder).
        return { response_version: 2, assistant_text: 'I can’t run the analysis yet: Option B does not set anything in the model.', suggested_actions: [], insights: [], graph_hash: T2.graph_hash, blocks: [], analysis_ready: blockedRunReady };
      }
      s.ran = true;
      return { assistant_text: 'Ran.', graph_hash: T2.graph_hash, blocks: [T2.analysis_result], analysis_ready: T2.analysis_ready, analysis_state: T2.analysis_state };
    }
    return { assistant_text: 'ok', blocks: [] };
  });
  await a.register(agentV1TurnRoute);
  await a.ready();
  return a;
}

function installRunStub() {
  runStub.impl = async (raw: unknown) => {
    const s = st((raw as { payload: { scenario_id: string } }).payload.scenario_id);
    s.inProcessRuns += 1;
    s.ran = true;
    return {
      outcome: 'ok', commitPerformed: true, graph: null, mayNameLeadingOption: false, analysisReady: T2.analysis_ready,
      response: { response_version: 2, assistant_text: 'Ran.', suggested_actions: [], insights: [], stage_indicator: 'analyse', blocks: [T2.analysis_result] },
    };
  };
}

type Block = Record<string, unknown> & { type?: string };
type Reply = {
  assistant_text?: string;
  blocks?: Block[];
  suggested_actions?: Array<Record<string, unknown>>;
  graph_hash?: string;
  analysis_ready?: { current_graph_hash?: string; status?: string };
  analysis_state?: { run_state?: { kind?: string; computed_at?: string }; leader_claim?: unknown };
  _diagnostic_trace: Record<string, unknown> & { fast_path?: string; coaching?: { eligible: boolean; reason?: string } };
  _provider_calls?: Array<Record<string, unknown>>;
};

const sha256 = (s: string) => createHash('sha256').update(s, 'utf8').digest('hex');
const written: Record<string, { path: string; sha256: string; bytes: number }> = {};
function save(name: string, raw: string): void {
  mkdirSync(OUT_DIR, { recursive: true });
  const path = `${OUT_DIR}/${LABEL}.${name}.route-body.json`;
  writeFileSync(path, raw);
  written[name] = { path, sha256: sha256(raw), bytes: Buffer.byteLength(raw) };
}

const SID_RUN = '7b1e2d3c-4a5f-4e6d-8c7b-8a9f0e1d2cf1';
const SID_BLOCKED = '7b1e2d3c-4a5f-4e6d-8c7b-8a9f0e1d2cf2';
const RUN_CHIP_PAYLOAD = { message: 'Run analysis', source: 'chip_click', chip: { id: 'agent-run-analysis', action_type: 'run_analysis' } };

const guardLedger = () => ((globalThis as { __PRB_BLOCKED__?: unknown[] }).__PRB_BLOCKED__ ?? []).length;
const meta: Record<string, unknown> = {};

describe(`PR-B route capture (${LABEL})`, () => {
  let app: FastifyInstance;
  let ledgerAtStart = 0;
  beforeAll(async () => {
    ledgerAtStart = guardLedger();
    installFetch();
    installRunStub();
    process.env.AGENT_LANE_ENABLED = 'true';
    process.env.AGENT_LANE_PREVIEW = 'false';
    app = await buildApp();
  }, 300_000);
  afterAll(async () => {
    await app.close();
    vi.unstubAllGlobals();
    delete process.env.AGENT_LANE_ENABLED; delete process.env.AGENT_LANE_PREVIEW;
    let cee_head = 'unknown';
    try { cee_head = execSync('git rev-parse HEAD', { cwd: process.cwd() }).toString().trim(); } catch { /* keep unknown */ }
    writeFileSync(`${OUT_DIR}/${LABEL}.capture-meta.json`, `${JSON.stringify({
      label: LABEL, cee_head, generated_at: new Date().toISOString(),
      how: 'real POST /agent/v1/turn via app.inject over the first-analysis-coaching-card harness double; scripted model fetch stub; no provider/network (PRB guard)',
      env: { OPENAI_API_KEY: process.env.OPENAI_API_KEY ?? null, ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY ?? null, ANTHROPIC_BASE_URL: process.env.ANTHROPIC_BASE_URL ?? '<unset>' },
      guard_ledger_delta_during_capture: guardLedger() - ledgerAtStart,
      model_calls: modelCalls,
      files: written,
      scripted: { RUN_REPLY, BLOCKED_REPLY, BUILD_REPLY },
      ...meta,
    }, null, 2)}\n`);
  });

  const turn = async (sid: string, payload: Record<string, unknown>) => {
    const r = await app.inject({ method: 'POST', url: '/agent/v1/turn', payload: { kind: 'message', scenario_id: sid, ...payload } });
    expect(r.statusCode, r.body.slice(0, 300)).toBe(200);
    return { raw: r.body, json: r.json() as Reply };
  };

  it('EXPLICIT RUN on a model with a fragile link: one current fragile-link card, bound to this reply', async () => {
    knobs = { graph: READY_GRAPH, run: 'complete' };
    script = [{ ...callTool('build_model_from_brief', { brief: BRIEF }) }];
    const build = await turn(SID_RUN, { message: BRIEF });
    save('build-turn-auto-first-pass', build.raw);
    expect(build.json._diagnostic_trace.first_analysis).toMatchObject({ ran: true });

    const run = await turn(SID_RUN, RUN_CHIP_PAYLOAD);
    save('explicit-run', run.raw);
    const r = run.json;
    expect(r._diagnostic_trace.fast_path).toBe('run');
    expect(st(SID_RUN).injectRuns).toBe(1);
    const cards = (r.blocks ?? []).filter((b) => b.type === 'coaching');
    expect(cards).toHaveLength(1);
    const card = cards[0]!;
    expect(CoachingBlockSchema.safeParse(card).success).toBe(true);
    expect(String(card.signal_id).endsWith(':explicit_run')).toBe(true);
    expect(r._diagnostic_trace.coaching).toEqual({ eligible: true });

    // ── The three-part currency rule, as the UI will evaluate it on THIS body ──
    const currency = {
      card_created_at: card.created_at,
      run_state_kind: r.analysis_state?.run_state?.kind,
      run_state_computed_at: r.analysis_state?.run_state?.computed_at,
      created_at_equals_computed_at: card.created_at === r.analysis_state?.run_state?.computed_at,
      card_graph_hash_at_generation: card.graph_hash_at_generation,
      response_graph_hash: r.graph_hash,
      analysis_ready_current_graph_hash: r.analysis_ready?.current_graph_hash,
      hash_equals_response_graph_hash: card.graph_hash_at_generation === r.graph_hash,
      hash_equals_analysis_ready_current_graph_hash: card.graph_hash_at_generation === r.analysis_ready?.current_graph_hash,
      card_freshness: card.freshness,
      card_source_handler: card.source_handler,
    };
    meta.explicit_run = {
      currency,
      card: { block_id: card.block_id, signal_id: card.signal_id, title: card.title, body: card.body, action_label: card.action_label, action_prompt: card.action_prompt, action_intent: card.action_intent, target_refs: card.target_refs },
      block_types: (r.blocks ?? []).map((b) => b.type),
      suggested_actions: r.suggested_actions,
      assistant_text: r.assistant_text,
      assistant_text_words: String(r.assistant_text ?? '').split(/\s+/).filter(Boolean).length,
      leader_claim_enforced: r._diagnostic_trace.leader_claim_enforced ?? false,
      provider_calls: r._provider_calls,
      diagnostic_trace: r._diagnostic_trace,
    };
    expect(currency.created_at_equals_computed_at).toBe(true);
    expect(currency.hash_equals_response_graph_hash).toBe(true);
    expect(currency.hash_equals_analysis_ready_current_graph_hash).toBe(true);
    expect(currency.run_state_kind).toBe('complete_current');
    expect(r.assistant_text).toContain('This run can’t yet say which pricing path to take');
    for (const c of r._provider_calls ?? []) expect(c.provider).toBe('openai');
  });

  it('BLOCKED RUN: no card (no run to bind), the next-step chip, Olumi’s reason', async () => {
    knobs = { graph: BLOCKED_GRAPH, run: 'blocked' };
    script = [{ ...callTool('build_model_from_brief', { brief: BRIEF }) }];
    const build = await turn(SID_BLOCKED, { message: BRIEF });
    expect(build.json._diagnostic_trace.first_analysis).toMatchObject({ ran: false, reason: 'not_admissible' });
    const run = await turn(SID_BLOCKED, RUN_CHIP_PAYLOAD);
    save('blocked-run', run.raw);
    const r = run.json;
    expect(r._diagnostic_trace.fast_path).toBe('run');
    expect(st(SID_BLOCKED).injectRuns).toBe(1);
    meta.blocked_run = {
      coaching: r._diagnostic_trace.coaching,
      block_types: (r.blocks ?? []).map((b) => b.type),
      suggested_actions: r.suggested_actions,
      assistant_text: r.assistant_text,
      analysis_state_run_state: r.analysis_state?.run_state,
      analysis_ready_status: r.analysis_ready?.status,
    };
    expect((r.blocks ?? []).filter((b) => b.type === 'coaching')).toEqual([]);
    expect((r.suggested_actions ?? []).map((a) => a.id)).toContain('agent-suggest-what-it-needs');
  });

  it('NO NETWORK: the guard ledger did not move while the route ran; every model call hit the stub with an empty key', () => {
    expect(guardLedger() - ledgerAtStart).toBe(0);
    expect(modelCalls.length).toBeGreaterThan(0);
    for (const c of modelCalls) {
      expect(c.url).toBe(OPENAI_URL);
      expect(c.authorization).toBe('Bearer ');
    }
  });
});
