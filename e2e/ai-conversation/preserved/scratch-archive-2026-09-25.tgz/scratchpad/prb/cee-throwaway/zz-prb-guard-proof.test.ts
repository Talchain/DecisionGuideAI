/**
 * THROWAWAY (not committed to CEE) — proof that the PRB network guard is live in THIS process.
 *
 * Uses reserved `.invalid` hosts ONLY (RFC 2606/6761 — they can never resolve) plus the loopback
 * egress-proxy port. NO provider host is ever named here: the guard is proven without sending
 * anything anywhere. A loopback positive control proves the guard is not simply blocking all
 * traffic (the route capture's loopback fakes must still work).
 */
import net from 'node:net';
import https from 'node:https';
import http from 'node:http';
import { writeFileSync } from 'node:fs';
import { describe, it, expect, afterAll } from 'vitest';

type Blocked = { layer: string; target: string };
const ledger = () => ((globalThis as { __PRB_BLOCKED__?: Blocked[] }).__PRB_BLOCKED__ ?? []);
const OUT_DIR = process.env.PRB_OUT_DIR ?? '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/prb';
const LABEL = process.env.PRB_LABEL ?? 'cee-unknown';
const PROXY_PORT = Number(process.env.PRB_EXTRA_BLOCKED_PORT ?? 45543);
const start = ledger().length;
const results: Record<string, string> = {};

const socketError = (s: net.Socket) => new Promise<string>((resolve) => {
  s.on('error', (e) => resolve(e.message));
  s.on('connect', () => { s.destroy(); resolve('CONNECTED (guard failed)'); });
});

describe(`PRB guard proof (${LABEL}) — .invalid hosts only`, () => {
  afterAll(() => {
    writeFileSync(`${OUT_DIR}/${LABEL}.guard-proof.json`, `${JSON.stringify({
      label: LABEL,
      hosts_used: ['prb-guard-proof.invalid', `127.0.0.1:${PROXY_PORT} (loopback egress proxy)`, '127.0.0.1:<ephemeral> (positive control)'],
      env: {
        OPENAI_API_KEY: process.env.OPENAI_API_KEY ?? null,
        ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY ?? null,
        ANTHROPIC_BASE_URL: process.env.ANTHROPIC_BASE_URL ?? '<unset>',
        proxy_like_vars_set: Object.keys(process.env).filter((k) => /proxy$/i.test(k)),
      },
      results,
      ledger_delta: ledger().length - start,
      ledger_entries: ledger().slice(start).map((b) => ({ layer: b.layer, target: b.target })),
    }, null, 2)}\n`);
  });

  it('env: no provider keys, no provider base URL, no proxy-shaped variable', () => {
    expect(process.env.OPENAI_API_KEY ?? '').toBe('');
    expect(process.env.ANTHROPIC_API_KEY ?? '').toBe('');
    expect(process.env.ANTHROPIC_BASE_URL).toBeUndefined();
    expect(Object.keys(process.env).filter((k) => /proxy$/i.test(k))).toEqual([]);
  });

  it('fetch to a .invalid host is refused by the guard before a request is built', async () => {
    const before = ledger().length;
    const err = await fetch('https://prb-guard-proof.invalid/v1/probe').then(() => 'RESOLVED (guard failed)', (e: Error) => e.message);
    results.fetch_invalid = err;
    expect(err).toContain('PRB_NETWORK_GUARD');
    expect(ledger().length - before).toBe(1);
  });

  it('fetch to the loopback egress-proxy port is refused', async () => {
    const before = ledger().length;
    const err = await fetch(`http://127.0.0.1:${PROXY_PORT}/`).then(() => 'RESOLVED (guard failed)', (e: Error) => e.message);
    results.fetch_proxy_port = err;
    expect(err).toContain('PRB_NETWORK_GUARD');
    expect(ledger().length - before).toBe(1);
  });

  it('net.connect to a .invalid host is destroyed by the socket guard before DNS/connect', async () => {
    const before = ledger().length;
    const msg = await socketError(net.connect({ host: 'prb-guard-proof.invalid', port: 443 }));
    results.socket_invalid = msg;
    expect(msg).toContain('PRB_NETWORK_GUARD');
    expect(ledger().length - before).toBe(1);
  });

  it('net.connect to the loopback egress-proxy port is destroyed by the socket guard', async () => {
    const before = ledger().length;
    const msg = await socketError(net.connect({ host: '127.0.0.1', port: PROXY_PORT }));
    results.socket_proxy_port = msg;
    expect(msg).toContain('PRB_NETWORK_GUARD');
    expect(ledger().length - before).toBe(1);
  });

  it('node:https (agent passes path:null) to a .invalid host is refused at the socket layer', async () => {
    const before = ledger().length;
    const msg = await new Promise<string>((resolve) => {
      const req = https.get('https://prb-guard-proof.invalid/v1/probe', () => resolve('RESPONSE (guard failed)'));
      req.on('error', (e) => resolve(e.message));
    });
    results.https_invalid = msg;
    expect(msg).toContain('PRB_NETWORK_GUARD');
    expect(ledger().length - before).toBeGreaterThanOrEqual(1);
  });

  it('positive control: a loopback (non-proxy) server is still reachable, and nothing is recorded', async () => {
    const server = http.createServer((_q, r) => { r.end('ok'); });
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
    const port = (server.address() as net.AddressInfo).port;
    const before = ledger().length;
    const body = await fetch(`http://127.0.0.1:${port}/`).then((r) => r.text());
    await new Promise<void>((r) => server.close(() => r()));
    results.loopback_positive_control = body;
    expect(body).toBe('ok');
    expect(ledger().length - before).toBe(0);
  });
});
