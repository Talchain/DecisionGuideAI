// Builds the DGAI fixtures from the c673223 route bodies: `_provenance` first, then the route body
// exactly as parsed. Verifies JSON.stringify(body) reproduces the raw route bytes (so the spec's
// sha256 re-derivation is over the route's own bytes).
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const PRB = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/prb';
const OUT = process.argv[2];
const SHA = 'c673223d7bc3f83fc344b68de53b44baf04c75f7';
const sha256 = (s) => createHash('sha256').update(s, 'utf8').digest('hex');
const c933 = (t) => sha256(readFileSync(`${PRB}/cee-c933aabf.${t}.route-body.json`, 'utf8'));

const common = {
  kind: 'ROUTE-GENERATED WITH A SCRIPTED MODEL — NOT A LIVE CAPTURE. No OpenAI or Anthropic call was made to produce it.',
  producer: `CEE olumi-assistants-service ${SHA} — the commit served on CEE staging on 2026-09-25 (git fetch origin staging → FETCH_HEAD = ${SHA}, PR #1854 squash-merged on top of caf7d1a3). Tree a49d3a14c8af443930811a1ae11817337f6a4047, the SAME tree as the local c933aabf+caf7d1a3 merge used for the c933aabf fixtures.`,
  route: 'POST /agent/v1/turn (agent lane), driven in-process by app.inject; the body below is the HTTP response body exactly as the route sent it (sha256 below is over those raw bytes = JSON.stringify of this object without _provenance).',
  harness: "CEE's own route test double from src/orchestrator-v5/agent-lane/__tests__/first-analysis-coaching-card.test.ts, reused unchanged by an untracked zz-prb-route-capture.test.ts: session store / identity / prior-facts mocked; scenario graph = fixtures/first-analysis-graphs.ts; the run and the post-run readback answer from the SERVED capture c19-8428207-B turn t2 (CEE 8428207, pricing model, constraint verdict withheld, leader withheld, robustness low, 12 fragile edges).",
  model: "The harness's scripted fetch stub. Every model call hit the stub with 'Bearer ' (empty key); the stub never forwards. A throwaway FIRST setup file refused every non-loopback fetch and socket connect (and the loopback egress-proxy port 45543); its ledger did not move during the capture. A separate guard proof in the same run used ONLY reserved .invalid hosts + the loopback proxy port (5 attempts, 5 refusals, loopback positive control reachable). Env: OPENAI_API_KEY='', ANTHROPIC_API_KEY='', ANTHROPIC_BASE_URL unset, every *proxy variable unset.",
  generated: '2026-09-25',
};

const turns = {
  'explicit-run': {
    file: 'openai-agent-run-explicit.route-c673223.json',
    turn: "Explicit Run: the typed Run chip {id:'agent-run-analysis', action_type:'run_analysis'} after a build turn whose automatic first pass ran (fast path 3: the run, then ONE tool_choice:'none' interpretation call).",
    scripted_reply: 'assistant_text is the SAME fixed 93-word interpretation (95 whitespace tokens, 2 of them bullet markers) used for the c933aabf capture, grounded only in the t2 run. It is NOT model output.',
    known_harness_artefacts: [
      "draft_graph is the harness's READY_GRAPH (Choose an option / Outcome / Delivery reliability / Option A / Option B) while analysis_result, analysis_ready and the coaching card come from the served pricing run t2 — the CEE harness pairs them. A served turn would carry the analysed model's own graph.",
      'suggested_actions is [] — the route offers no chip on a COMPLETED explicit Run (by design: run-fast-path.test.ts "a COMPLETED Run offers no remedy chip").',
    ],
  },
  'blocked-run': {
    file: 'openai-agent-run-blocked.route-c673223.json',
    turn: "Blocked Run: the same typed Run chip on a model whose Option B sets nothing (BLOCKED_GRAPH); the product double answers HTTP 200 with no analysis_result and CEE's own readiness for that graph (needs_user_input, one missing_value blocker).",
    scripted_reply: 'assistant_text is the fixed BLOCKED_REPLY interpretation written for the capture. It is NOT model output.',
    known_harness_artefacts: ['_provider_calls[0].duration_ms is wall-clock and differs from the c933aabf capture (0 → 1); nothing else does.'],
  },
  'build-turn-auto-first-pass': {
    file: 'openai-agent-build-turn-first-pass.route-c673223.json',
    turn: 'Build turn: the brief, answered by a scripted build_model_from_brief tool call; the automatic first analysis (PR #1854) ran once on the model just built and carried its own coaching card (signal suffix :auto_first_pass).',
    scripted_reply: "assistant_text starts with the scripted BUILD_REPLY 'Here is a provisional first pass to argue with.'; the remainder is the route's own composition.",
    known_harness_artefacts: ['_diagnostic_trace.first_analysis.run_turn_id is a fresh UUID per run and differs from the c933aabf capture; nothing else does.'],
  },
};

for (const [t, meta] of Object.entries(turns)) {
  const raw = readFileSync(`${PRB}/cee-c673223.${t}.route-body.json`, 'utf8');
  const body = JSON.parse(raw);
  if (JSON.stringify(body) !== raw) throw new Error(`${t}: JSON.stringify does not reproduce the raw route bytes`);
  const { file, ...rest } = meta;
  const provenance = {
    ...common,
    ...rest,
    route_body_sha256: sha256(raw),
    route_body_bytes: Buffer.byteLength(raw),
    c933aabf_route_body_sha256: c933(t),
    byte_identical_to_c933aabf: sha256(raw) === c933(t),
  };
  writeFileSync(`${OUT}/${file}`, `${JSON.stringify({ _provenance: provenance, ...body }, null, 2)}\n`);
  console.log(file, provenance.route_body_sha256, provenance.route_body_bytes, 'identical-to-c933aabf:', provenance.byte_identical_to_c933aabf);
}
