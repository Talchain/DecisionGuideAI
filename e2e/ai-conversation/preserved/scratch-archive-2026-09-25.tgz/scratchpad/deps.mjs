import fs from 'fs'; import path from 'path'
const start = process.argv[2]; const targets = process.argv.slice(3)
const seen = new Map(); const q = [[path.resolve(start), null]]
function resolve(from, spec){ if(!spec.startsWith('.')) return null; const base = path.resolve(path.dirname(from), spec)
 for (const ext of ['', '.ts','.tsx','/index.ts','/index.tsx']) { const p = base+ext; if (fs.existsSync(p) && fs.statSync(p).isFile()) return p } return null }
while(q.length){ const [f, parent] = q.shift(); if(seen.has(f)) continue; seen.set(f, parent)
 const src = fs.readFileSync(f,'utf8')
 const re = /^\s*import\s+(?!type\b)[^'"]*?from\s+['"]([^'"]+)['"]|^\s*import\s+['"]([^'"]+)['"]|^\s*export\s+(?!type\b)[^'"]*?from\s+['"]([^'"]+)['"]/gms
 let m; while((m = re.exec(src))){ const spec = m[1]||m[2]||m[3]; const r = resolve(f, spec); if(r && !seen.has(r)) q.push([r, f]) } }
for (const t of targets){ const tp = path.resolve(t); if(seen.has(tp)){ let chain=[tp]; let p=seen.get(tp); while(p){chain.push(p); p=seen.get(p)} console.log('REACHES', t, '\n  ' + chain.reverse().map(x=>path.relative(process.cwd(),x)).join('\n  -> ')) } else console.log('no path to', t) }
console.log('visited', seen.size)
