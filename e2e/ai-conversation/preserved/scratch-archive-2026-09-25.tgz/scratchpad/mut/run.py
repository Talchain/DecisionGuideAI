import subprocess, os, re, sys
ROOT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-abe6e9e5dbd1e7227'
OUT = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/mut'
HOOK = 'src/canvas/conversation/hooks/useSmartScroll.ts'
THREAD = 'src/canvas/conversation/zones/ChatThread.tsx'
MSG = 'src/canvas/conversation/zones/ChatMessage.tsx'
SPEC = 'src/canvas/conversation/__tests__/ChatThread.replyStartInView.spec.tsx'
M = [
 ('M1', MSG, "      {...{ [MESSAGE_ID_ATTRIBUTE]: message.id }}\n", "", 'ChatMessage no longer stamps data-message-id'),
 ('M2', THREAD, "useSmartScroll({ messageCount: renderedMessageCount, isThinking, messages })", "useSmartScroll({ messageCount: renderedMessageCount, isThinking })", 'ChatThread does not pass messages to the hook'),
 ('M3', HOOK, "  if (i < 0) return null\n", "", 'arrivedReplyId: a replaced list (previous newest gone) treated as an append'),
 ('M4', HOOK, "  if (appended.some((m) => m.role === 'user')) return null\n", "", 'arrivedReplyId: a user message in the appended batch no longer vetoes the hold'),
 ('M5', HOOK, "    if (newestId === previousNewestId) return\n", "", 'layout effect: re-derives the hold on every messages change'),
 ('M6', HOOK, "    if (!holdAtReplyStart()) listEndRef.current?.scrollIntoView({ behavior })", "    listEndRef.current?.scrollIntoView({ behavior })", 'pinOrNotify: hold bypassed (old bottom pin)'),
 ('M7', HOOK, "    if (list.scrollHeight - list.clientHeight <= startTop) return false\n", "", 'holdAtReplyStart: fits check removed'),
 ('M8', HOOK, "    if (list.scrollTop < startTop) list.scrollTop = startTop", "    list.scrollTop = startTop", 'holdAtReplyStart: forward-only removed'),
 ('M9', HOOK, "const atReplyStart = startTop !== null && Math.abs(el.scrollTop - startTop) <= SCROLL_THRESHOLD_PX", "const atReplyStart = false", 'handleScroll: reply-start band removed'),
 ('M10', HOOK, "    if (isNearBottom && startTop !== null && el.scrollTop > startTop + SCROLL_THRESHOLD_PX) {\n      replyStartIdRef.current = null\n    }\n", "", 'handleScroll: reaching the bottom no longer releases the hold'),
 ('M11', HOOK, "    userScrolledUpRef.current = false\n    replyStartIdRef.current = null\n", "    userScrolledUpRef.current = false\n", 'scrollToBottom (pill): no longer releases the hold'),
 ('M12', HOOK, "const REPLY_START_GAP_PX = 12", "const REPLY_START_GAP_PX = 0", 'gap above the reply start 12 -> 0'),
 ('M13', HOOK, "  useLayoutEffect(() => {\n    if (!messages) return", "  useEffect(() => {\n    if (!messages) return", 'arrival detection: layout effect -> passive effect'),
 ('M14', HOOK, "  return appended.find((m) => m.role === 'assistant')?.id ?? null", "  return null", 'arrivedReplyId never names a reply'),
]
only = sys.argv[1:] or None
rows = []
for mid, path, old, new, desc in M:
    if only and mid not in only:
        continue
    fp = os.path.join(ROOT, path)
    src = open(fp).read()
    assert src.count(old) == 1, (mid, src.count(old))
    open(fp, 'w').write(src.replace(old, new))
    try:
        env = dict(os.environ, VITE_SUPABASE_URL='http://localhost', VITE_SUPABASE_ANON_KEY='test')
        r = subprocess.run(['npx', 'vitest', 'run', SPEC], cwd=ROOT, env=env, capture_output=True, text=True, timeout=600)
        out = r.stdout + r.stderr
        open(os.path.join(OUT, mid + '.log'), 'w').write(out)
        failed = re.findall(r'FAIL\s+\S+ > [^>]+ > (.+)', out)
        summ = re.findall(r'Tests\s+(.+)', out)
        rows.append((mid, desc, r.returncode, summ[-1].strip() if summ else '?', sorted(set(f.strip() for f in failed))))
    finally:
        open(fp, 'w').write(src)
for row in rows:
    print(f"{row[0]} | exit={row[2]} | {row[3]} | {row[1]}")
    for f in row[4]:
        print('     RED:', f)
