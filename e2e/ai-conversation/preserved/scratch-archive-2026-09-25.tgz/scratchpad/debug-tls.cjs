// Debug: which connect path does node:https take? Uses only the reserved .invalid TLD — no real host.
const net = require('node:net');
const tls = require('node:tls');
const https = require('node:https');
const real = net.Socket.prototype.connect;
let seen = [];
net.Socket.prototype.connect = function (...args) {
  const o = Array.isArray(args[0]) ? args[0][0] : args[0]; seen.push({isArray: Array.isArray(args[0]), host: o && o.host, port: o && o.port, path: o && o.path, socketPath: o && o.socketPath});
  return real.apply(this, args);
};
console.log('TLSSocket own connect?', Object.prototype.hasOwnProperty.call(tls.TLSSocket.prototype, 'connect'));
const req = https.request('https://prb-guard-test.invalid/v1/messages', { method: 'POST' }, () => console.log('response?!'));
req.on('error', (e) => { console.log('error:', e.message); console.log(seen); });
req.end('{}');
