// Builds the UI fixtures from the raw route bodies: `_provenance` first, then the body's own keys in
// the route's order. Verifies JSON.stringify(body) reproduces the raw route bytes exactly.
const fs = require('node:fs');
const crypto = require('node:crypto');
const SRC = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/prb';
const DST = '/home/user/DecisionGuideAI/.claude/worktrees/agent-ad9a1db073416fa03/src/canvas/conversation/__tests__/fixtures';
const sha = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');

const common = {
  kind: 'ROUTE-GENERATED WITH A SCRIPTED MODEL — NOT A LIVE CAPTURE. No OpenAI or Anthropic call was made to produce it.',
  producer: 'CEE olumi-assistants-service PR #1854 approved head c933aabfaffb4cac5572b7962d9e3a3658996de0 (fetched as refs/pull/1854/head). The same test on c933aabf merged locally with staging caf7d1a3 (merge tree a49d3a14c8af443930811a1ae11817337f6a4047, not pushed) produced a byte-identical body.',
  route: 'POST /agent/v1/turn (agent lane), driven in-process by app.inject; the body below is the HTTP response body exactly as the route sent it (sha256 below is over those raw bytes = JSON.stringify of this object without _provenance).',
  harness: "CEE's own route test double from src/orchestrator-v5/agent-lane/__tests__/first-analysis-coaching-card.test.ts: session store / identity / prior-facts mocked; scenario graph = fixtures/first-analysis-graphs.ts; the run and the post-run readback answer from the SERVED capture c19-8428207-B turn t2 (CEE 8428207, pricing model, constraint verdict withheld, leader withheld, robustness low, 12 fragile edges).",
  model: "The harness's scripted fetch stub. Every model call hit the stub with 'Bearer ' (empty key). A throwaway setup guard refused every non-loopback fetch and socket (and the loopback egress-proxy port); its ledger did not move during the capture. Env: OPENAI_API_KEY='', ANTHROPIC_API_KEY='', ANTHROPIC_BASE_URL unset, proxy variables unset.",
  generated: '2026-09-24',
};

const specs = [
  {
    raw: `${SRC}/cee-c933aabf.explicit-run.route-body.json`,
    out: `${DST}/openai-agent-run-explicit.prb-route-c933aabf.json`,
    extra: {
      turn: "Explicit Run: the typed Run chip {id:'agent-run-analysis', action_type:'run_analysis'} after a build turn whose automatic first pass ran (fast path 3: the run, then ONE tool_choice:'none' interpretation call).",
      scripted_reply: 'assistant_text is a fixed 95-word interpretation written for this capture in the Interpreter v0.2 / AI Quality shape (finding + caveat first, two grounded bullets, one next step), grounded only in the t2 run. It is NOT model output.',
      known_harness_artefacts: [
        "draft_graph is the harness's READY_GRAPH (Choose an option / Outcome / Delivery reliability / Option A / Option B) while analysis_result, analysis_ready and the coaching card come from the served pricing run t2 — the CEE harness pairs them. A served turn would carry the analysed model's own graph.",
        'suggested_actions is [] — the route offers no chip on a COMPLETED explicit Run (by design: run-fast-path.test.ts "a COMPLETED Run offers no remedy chip").',
      ],
    },
  },
  {
    raw: `${SRC}/cee-c933aabf.blocked-run.route-body.json`,
    out: `${DST}/openai-agent-run-blocked.prb-route-c933aabf.json`,
    extra: {
      turn: "Blocked explicit Run: the same typed Run chip on the harness's BLOCKED_GRAPH (Option B sets nothing). The run answered HTTP 200 with no analysis_result and CEE's own canonical readiness for that graph; the first pass did not run (not_admissible).",
      scripted_reply: 'assistant_text is a fixed interpretation written for this capture; it is NOT model output.',
      known_harness_artefacts: [],
    },
  },
];

for (const s of specs) {
  const raw = fs.readFileSync(s.raw, 'utf8');
  const body = JSON.parse(raw);
  if (JSON.stringify(body) !== raw) throw new Error(`round-trip mismatch for ${s.raw}`);
  const fixture = { _provenance: { ...common, ...s.extra, route_body_sha256: sha(raw), route_body_bytes: Buffer.byteLength(raw) }, ...body };
  fs.writeFileSync(s.out, `${JSON.stringify(fixture, null, 2)}\n`);
  const back = JSON.parse(fs.readFileSync(s.out, 'utf8'));
  delete back._provenance;
  if (sha(JSON.stringify(back)) !== sha(raw)) throw new Error('fixture body does not reproduce the route bytes');
  console.log(s.out, 'route_body_sha256', sha(raw), 'fixture file sha256', sha(fs.readFileSync(s.out, 'utf8')));
}
