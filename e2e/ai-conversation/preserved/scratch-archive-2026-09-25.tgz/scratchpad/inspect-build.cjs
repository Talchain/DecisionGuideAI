const b = require('/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/prb/cee-c933aabf.build-turn-auto-first-pass.route-body.json');
const cards = (b.blocks || []).filter((x) => x.type === 'coaching');
console.log('build turn block types', (b.blocks || []).map((x) => x.type));
console.log('card', cards.map((c) => ({ signal_id: c.signal_id, created_at: c.created_at, hash: c.graph_hash_at_generation, body: c.body })));
console.log('run_state', JSON.stringify(b.analysis_state && b.analysis_state.run_state), 'graph_hash', b.graph_hash, 'ready.current', b.analysis_ready && b.analysis_ready.current_graph_hash);
console.log('suggested_actions', JSON.stringify(b.suggested_actions));
console.log('assistant_text', b.assistant_text);
console.log('trace', JSON.stringify(b._diagnostic_trace));
