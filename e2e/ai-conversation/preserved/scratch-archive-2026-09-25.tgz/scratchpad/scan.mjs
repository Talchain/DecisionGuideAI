import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'
const root = process.argv[2]
function walkFiles(d) {
  const out = []
  for (const f of readdirSync(d)) {
    const p = join(d, f)
    if (statSync(p).isDirectory()) out.push(...walkFiles(p))
    else if (p.endsWith('.json')) out.push(p)
  }
  return out
}
const files = [
  ...walkFiles(join(root, 'tests/fixtures/cee-responses')),
  ...readdirSync(join(root, 'src/v5/__tests__/fixtures'))
    .filter((f) => /^live-analysis-turn-.*\.json$/.test(f))
    .map((f) => join(root, 'src/v5/__tests__/fixtures', f)),
]
for (const f of files) {
  const j = JSON.parse(readFileSync(f, 'utf8'))
  const types = {}
  let sh = 0
  let ca = 0
  const shv = new Set()
  const walk = (v) => {
    if (Array.isArray(v)) v.forEach(walk)
    else if (v && typeof v === 'object') {
      if (typeof v.type === 'string') {
        types[v.type] = (types[v.type] || 0) + 1
        if (v.type === 'coaching') {
          if ('source_handler' in v) { sh++; shv.add(v.source_handler) }
          if ('created_at' in v) ca++
        }
      }
      Object.values(v).forEach(walk)
    }
  }
  walk(j)
  console.log(f.replace(root + '/', ''), JSON.stringify({ coaching: types.coaching || 0, sh, ca, shv: [...shv] }))
}
