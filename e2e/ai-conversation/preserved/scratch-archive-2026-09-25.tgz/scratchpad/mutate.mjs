// Mutation harness: apply ONE mutation, run the spec, restore EXACTLY, verify sha.
import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { spawnSync } from 'child_process'

const ROOT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-ae0a1196dc98bd4dc'
const SPECS = (process.env.SPECS ?? 'src/canvas/conversation/__tests__/cardActionSettledReload.spec.tsx').split(' ')
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex')

const MUTANTS = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'))
const only = process.argv[3]
const rows = []
for (const m of MUTANTS) {
  if (only && m.id !== only) continue
  const file = path.join(ROOT, m.file)
  const original = fs.readFileSync(file, 'utf8')
  const before = sha(original)
  const count = original.split(m.find).length - 1
  if (count !== 1) {
    rows.push({ id: m.id, applied: `find matched ${count}x — NOT APPLIED`, exit: null, red: [] })
    continue
  }
  fs.writeFileSync(file, original.replace(m.find, m.replace))
  let res
  try {
    res = spawnSync('npx', ['vitest', 'run', ...SPECS], {
      cwd: ROOT,
      env: { ...process.env, VITE_SUPABASE_URL: 'http://localhost', VITE_SUPABASE_ANON_KEY: 'test' },
      encoding: 'utf8',
      maxBuffer: 256 * 1024 * 1024,
      timeout: 600000,
    })
  } finally {
    fs.writeFileSync(file, original)
  }
  const after = sha(fs.readFileSync(file, 'utf8'))
  if (after !== before) throw new Error(`RESTORE FAILED for ${m.file}`)
  const out = (res.stdout ?? '') + (res.stderr ?? '')
  const red = [...new Set([...out.matchAll(/FAIL\s+\S+\s+>\s+(.+)/g)].map((x) => x[1].trim()))]
  const summary = (out.match(/Tests\s+.+/) ?? [''])[0].trim()
  rows.push({ id: m.id, applied: 'yes', exit: res.status, summary, red })
}
for (const r of rows) {
  console.log(`\n## ${r.id} applied=${r.applied} exit=${r.exit} ${r.summary ?? ''}`)
  for (const t of r.red) console.log(`   RED: ${t}`)
}
