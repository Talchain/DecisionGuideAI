import json, re, sys
for line in open(sys.argv[1]):
    m = re.match(r'.*AICWITNESS (\S+) (\{.*\})\s*$', line)
    if not m:
        continue
    d = json.loads(m.group(2))
    print('==', m.group(1))
    n = d['net']
    print(' net:', json.dumps({k: n[k] for k in ['total', 'local', 'inline', 'nonLocal', 'aborted', 'nonLocalCompleted', 'turnSubpaths', 'readinessServed', 'backendAnswers', 'websockets']}))
    for t in n['turns']:
        print('  turn', json.dumps(t))
    for k in ['before', 'afterForced', 'afterTalk', 'after']:
        if k in d:
            x = d[k]
            print(' ', k, json.dumps({'run': x['runChip'], 'talk': x['talkChip'], 'reason': x['reason'], 'dock': x['dockAnalyse'], 'toasts': x['toasts'], 'bubbles': x['userBubbles']}))
    for k in ['runTurnsAfterForced', 'turnsAfterForced', 'attempts']:
        if k in d:
            print(' ', k, d[k])
