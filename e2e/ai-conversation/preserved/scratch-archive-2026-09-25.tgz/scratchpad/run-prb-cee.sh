#!/usr/bin/env bash
# Runs the throwaway PR-B vitest files in a CEE worktree with NO provider credentials and NO proxy.
# usage: run-prb-cee.sh <cee-worktree> <vitest file filter...>
set -u
WT="$1"; shift
unset ANTHROPIC_BASE_URL HTTPS_PROXY https_proxy HTTP_PROXY http_proxy ALL_PROXY all_proxy GLOBAL_AGENT_HTTPS_PROXY GLOBAL_AGENT_HTTP_PROXY
export OPENAI_API_KEY=
export ANTHROPIC_API_KEY=
cd "$WT" || exit 99
echo "[run-prb] cwd=$(pwd) head=$(git rev-parse HEAD)"
echo "[run-prb] OPENAI_API_KEY='${OPENAI_API_KEY}' ANTHROPIC_API_KEY='${ANTHROPIC_API_KEY}' ANTHROPIC_BASE_URL=${ANTHROPIC_BASE_URL-<unset>} HTTPS_PROXY=${HTTPS_PROXY-<unset>}"
timeout 600 ./node_modules/.bin/vitest run -c vitest.prb.config.ts "$@"
rc=$?
echo "[run-prb] vitest exit code: $rc"
exit $rc
