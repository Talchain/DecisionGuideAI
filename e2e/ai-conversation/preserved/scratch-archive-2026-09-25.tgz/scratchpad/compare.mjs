import { readFileSync } from 'node:fs'
const dir = '/tmp/claude-0/-home-user-DecisionGuideAI/3e858362-52e3-5901-b78b-dc2e94bad241/scratchpad/'
const oldB = JSON.parse(readFileSync(dir + 'baseline-old.json', 'utf8'))
const newB = JSON.parse(readFileSync(dir + 'baseline-new.json', 'utf8'))
let blocks = 0
let withNew = 0
let mismatch = 0
for (const f of Object.keys(oldB)) {
  const o = oldB[f]
  const n = newB[f]
  if (o.length !== n.length) { console.log('LEN MISMATCH', f); mismatch++; continue }
  for (let i = 0; i < o.length; i++) {
    blocks++
    const nObj = JSON.parse(n[i])
    if (nObj && ('source_handler' in nObj || 'created_at' in nObj)) withNew++
    if (nObj) { delete nObj.source_handler; delete nObj.created_at }
    if (JSON.stringify(nObj) !== o[i]) { mismatch++; console.log('MISMATCH', f, i) }
  }
}
console.log({ files: Object.keys(oldB).length, blocks, withNew, mismatch })
