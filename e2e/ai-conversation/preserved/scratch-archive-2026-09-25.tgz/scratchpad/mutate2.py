"""Item-2 mutation checks: apply one mutation, run the named specs, restore the file's exact prior bytes."""
import os
import subprocess
import sys

ROOT = '/home/user/DecisionGuideAI/.claude/worktrees/agent-a7c5049cd3381e63d'
RC = 'src/v5/blocks/__tests__/V5CoachingBlock.runTurnCurrency.spec.tsx'
PR = 'src/canvas/conversation/__tests__/runTurnCoachingPromotion.spec.tsx'
CC = 'src/v5/blocks/coachingCurrency.ts'
HOOK = 'src/v5/blocks/useCoachingCurrency.ts'
CARD = 'src/v5/blocks/V5CoachingBlock.tsx'

A_LINE = "  if (authored && current && authored !== current) return 'model_changed'\n"
C_LINE = "  if (createdAt !== computedAt) return 'earlier_run'\n"


def move_a_after_b(src):
    assert src.count(A_LINE) == 1 and src.count(C_LINE) == 1
    return src.replace(A_LINE, '').replace(C_LINE, A_LINE + C_LINE)


MUTATIONS = [
    ('N1 (a) model_changed branch removed', CC, A_LINE, '', [RC, PR]),
    ('N2 (b) earlier_analysis branch removed', CC, "    return 'earlier_analysis'\n", '    // mutated\n', [RC]),
    ('N3 (c) earlier_run branch removed', CC, C_LINE, '', [RC, PR]),
    ('N4 precedence: (a) evaluated after (b)', CC, None, move_a_after_b, [RC]),
    ('N5 earlier_run copy -> the model-changed sentence', CC,
     "  earlier_run: 'Written about an earlier run of this model — the latest run may point somewhere else.',\n",
     '  earlier_run: FRESHNESS_NOTICE.stale as string,\n', [RC, PR]),
    ('N6 earlier_analysis copy re-worded', CC,
     "  earlier_analysis: 'Written about an earlier analysis — re-run to check it still holds.',\n",
     "  earlier_analysis: 'Written about an earlier analysis.',\n", [RC]),
    ('N7 resolveFreshnessNotice ignores the reason', CC,
     '    (runTurnReason ? RUN_TURN_NOTICE[runTurnReason] : undefined) ??\n', '', [RC, PR]),
    ('N8 resolveFreshnessNotice: reason outranks the producer verdict', CC,
     "    (producerFreshness ? FRESHNESS_NOTICE[producerFreshness] : undefined) ??\n"
     "    (runTurnReason ? RUN_TURN_NOTICE[runTurnReason] : undefined) ??\n",
     "    (runTurnReason ? RUN_TURN_NOTICE[runTurnReason] : undefined) ??\n"
     "    (producerFreshness ? FRESHNESS_NOTICE[producerFreshness] : undefined) ??\n", [RC]),
    ('N9 V5CoachingBlock passes no reason', CARD,
     'resolveFreshnessNotice(block.freshness, currency, runTurnReason)',
     'resolveFreshnessNotice(block.freshness, currency, null)', [RC, PR]),
    ('N10 sibling hook stops reading the current hash', HOOK,
     'useCanvasStore((s) => s.analysisFreshness?.currentGraphHash)',
     'useCanvasStore(() => undefined as string | undefined)', [RC]),
    ('N11 refresh-intent exemption removed', CARD,
     'Boolean(freshnessNotice) && !isRefreshActionIntent(block.action_intent)',
     'Boolean(freshnessNotice) && !isRefreshActionIntent(undefined)', [RC]),
    ('N12 reason no longer gated on run_analysis', CC,
     '  if (!isRunTurnCoachingCard(runTurn.sourceHandler)) return null\n', '', [RC]),
]

env = dict(os.environ, VITE_SUPABASE_URL='http://localhost', VITE_SUPABASE_ANON_KEY='test')
only = sys.argv[1:]
results = []
for name, rel, old, new, specs in MUTATIONS:
    if only and name.split()[0] not in only:
        continue
    path = os.path.join(ROOT, rel)
    original = open(path, 'rb').read()
    src = original.decode('utf8')
    if old is None:
        mutated = new(src)
    else:
        if src.count(old) != 1:
            results.append((name, 'SKIPPED: anchor matched %d times' % src.count(old)))
            continue
        mutated = src.replace(old, new)
    open(path, 'w').write(mutated)
    try:
        per = []
        for spec in specs:
            p = subprocess.run(['npx', 'vitest', 'run', spec], cwd=ROOT, env=env,
                               capture_output=True, text=True, timeout=600)
            out = p.stdout + p.stderr
            line = [l for l in out.splitlines() if l.strip().startswith('Tests ')]
            per.append('%s: %s %s' % (os.path.basename(spec), 'RED' if p.returncode else 'GREEN',
                                      line[-1].strip() if line else ''))
        results.append((name, ' | '.join(per)))
    finally:
        open(path, 'wb').write(original)

for name, r in results:
    print(name, '=>', r)
