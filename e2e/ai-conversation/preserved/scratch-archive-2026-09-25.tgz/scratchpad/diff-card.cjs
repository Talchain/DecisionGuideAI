const b = require(process.argv[2]);
const golden = require('/home/user/cee-prb-wt/src/orchestrator-v5/coaching/__tests__/fixtures/fragile-link-challenge.payload.json');
const card = (b.blocks || []).find((x) => x.type === 'coaching');
const g = golden.explicit_run.blocks[0];
console.log('golden keys', Object.keys(golden));
const keys = new Set([...Object.keys(card), ...Object.keys(g)]);
let same = true;
for (const k of keys) if (JSON.stringify(card[k]) !== JSON.stringify(g[k])) { same = false; console.log('DIFF', k, JSON.stringify(card[k]), '| golden', JSON.stringify(g[k])); }
console.log('card identical to producer golden explicit_run block (key-by-key):', same);
console.log('key order card  :', Object.keys(card).join(','));
console.log('key order golden:', Object.keys(g).join(','));
