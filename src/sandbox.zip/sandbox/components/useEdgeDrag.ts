import { useState, useEffect, useCallback } from 'react';
import type { Node as SandboxNode } from '../../types/sandbox';

interface EdgeDragState {
  creatingEdge: boolean;
  dragSource: SandboxNode | null;
  dragPos: { x: number; y: number } | null;
  onEdgeHandleMouseDown: (e: React.MouseEvent, node: SandboxNode) => void;
  setCreatingEdge: React.Dispatch<React.SetStateAction<boolean>>;
  setDragSource: React.Dispatch<React.SetStateAction<SandboxNode | null>>;
  setDragPos: React.Dispatch<React.SetStateAction<{ x: number; y: number } | null>>;
}

export function useEdgeDrag(board: { nodes: SandboxNode[] }, addEdge: Function) : EdgeDragState {
  const [creatingEdge, setCreatingEdge] = useState(false);
  const [dragSource, setDragSource] = useState<SandboxNode | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!creatingEdge) return;
    const onMove = (e: Event) => {
      const mouseEvent = e as unknown as MouseEvent;
      const canvas = document.getElementById('sandbox-canvas-root') as HTMLDivElement | null;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      setDragPos({ x: mouseEvent.clientX - rect.left, y: mouseEvent.clientY - rect.top });
    };
    const onUp = (e: Event) => {
      const mouseEvent = e as unknown as MouseEvent;
      setCreatingEdge(false);
      setDragPos(null);
      if (!dragSource || !board) return;
      const canvas = document.getElementById('sandbox-canvas-root') as HTMLDivElement | null;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const x = mouseEvent.clientX - rect.left;
      const y = mouseEvent.clientY - rect.top;
      // Find target node
      const target = board.nodes.find(n => x >= n.x && x <= n.x + 140 && y >= n.y && y <= n.y + 60);
      if (target && target.id !== dragSource.id) {
        try {
          addEdge({ source: dragSource.id, target: target.id, likelihood: 50 });
        } catch (err) {
          // Error handling will be at the toast/modal level
        }
      }
      setDragSource(null);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [creatingEdge, dragSource, board, addEdge]);

  const onEdgeHandleMouseDown = useCallback((e: React.MouseEvent, node: SandboxNode) => {
    e.stopPropagation();
    setCreatingEdge(true);
    setDragSource(node);
    setDragPos({ x: node.x + 60, y: node.y + 30 });
  }, []);

  return {
    creatingEdge,
    dragSource,
    dragPos,
    onEdgeHandleMouseDown,
    setCreatingEdge,
    setDragSource,
    setDragPos
  };
}
