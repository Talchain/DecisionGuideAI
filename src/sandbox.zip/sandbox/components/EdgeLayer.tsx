import React from 'react';
import type { Node as SandboxNode, Edge } from '../../types/sandbox';

interface EdgeLayerProps {
  nodes: SandboxNode[];
  edges: Edge[];
  selectedEdge: Edge | null;
  setSelectedEdge: (edge: Edge | null) => void;
  setSelectedNode: (node: SandboxNode | null) => void;
  toolbarPos: { x: number; y: number };
  setToolbarPos: (pos: { x: number; y: number }) => void;
  onEdgeClick: (edge: Edge, e: React.MouseEvent<SVGPathElement>) => void;
  onEdgeContext: (edge: Edge, e: React.MouseEvent) => void;
  onShowComments: (edgeId: string) => void; // Show comments panel for edge
}

export const EdgeLayer: React.FC<EdgeLayerProps> = React.memo(({
  nodes,
  edges,
  selectedEdge,
  setSelectedEdge,
  setSelectedNode,
  toolbarPos,
  setToolbarPos,
  onEdgeClick,
  onEdgeContext,
  onShowComments
}) => {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none">
      <defs>
        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
          <polygon points="0 0, 10 3.5, 0 7" className="fill-purple-500" />
        </marker>
        <marker id="arrowhead-selected" markerWidth="12" markerHeight="8" refX="10" refY="4" orient="auto">
          <polygon points="0 0, 12 4, 0 8" className="fill-purple-700" />
        </marker>
      </defs>
      {edges.map(edge => {
        const src = nodes.find(n => n.id === edge.source);
        const tgt = nodes.find(n => n.id === edge.target);
        if (!src || !tgt) return null;
        const midX = (src.x + tgt.x)/2 + 60;
        const midY = (src.y + tgt.y)/2;
        const d = `M${src.x+60},${src.y+30} Q${midX},${midY} ${tgt.x+60},${tgt.y+30}`;
        const sel = selectedEdge?.id === edge.id;
        return (
          <g key={edge.id}>
            <path
              d={d}
              fill="none"
              stroke="transparent"
              strokeWidth={20}
              className="pointer-events-auto"
              onClick={e => onEdgeClick(edge, e)}
              onContextMenu={e => onEdgeContext(edge, e)}
            />
            <path d={d} fill="none" stroke={sel ? '#6d28d9':'#8b5cf6'} strokeWidth={sel?3:2} strokeLinecap="round" markerEnd={`url(#${sel?'arrowhead-selected':'arrowhead'})`} />
            <text x={midX} y={midY-10} textAnchor="middle" className="text-xs font-medium fill-gray-700 pointer-events-none">{edge.likelihood||50}%</text>
            {/* Comment icon overlay (feature-flagged, positioned at midpoint) */}
            {import.meta.env.VITE_FEATURE_SCENARIO_SANDBOX === 'true' && (
              <foreignObject x={midX-14} y={midY+2} width={28} height={28} style={{overflow:'visible'}}>
                <button
                  className="w-7 h-7 flex items-center justify-center bg-gray-100 rounded-full shadow hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400"
                  title="Show comments"
                  aria-label="Show comments for edge"
                  tabIndex={0}
                  onClick={e => { e.stopPropagation(); console.log('onShowComments called for edge', edge.id, 'fn:', onShowComments); onShowComments(edge.id); }}
                >
                  <span aria-hidden="true" style={{fontSize: '1.1rem'}}>💬</span>
                </button>
              </foreignObject>
            )}
          </g>
        );
      })}
    </svg>
  );
});
