import React, { useRef } from 'react';
import type { Node as SandboxNode } from '../../types/sandbox';
import { RadialAddMenu } from './RadialAddMenu';

interface NodeLayerProps {
  nodes: SandboxNode[];
  updateNode: (nodeId: string, updates: Partial<SandboxNode>) => void; // Added for drag support
  selectedNode: SandboxNode | null;
  editValue: string;
  setEditValue: (val: string) => void;
  onSaveEdit: () => void;
  onNodeDouble: (node: SandboxNode) => void;
  onNodeContext: (node: SandboxNode, e: React.MouseEvent) => void;
  onNodeClick: (node: SandboxNode, e: React.MouseEvent<HTMLDivElement>) => void;
  onShowComments: (nodeId: string) => void; // Show comments panel for node
  isDraft: boolean;
  featureEnabled: boolean;
  addNode: (node: Partial<SandboxNode>) => SandboxNode;
  addEdge: (edge: { source: string; target: string }) => void;
}

export const NodeLayer: React.FC<NodeLayerProps> = React.memo(({
  nodes,
  selectedNode,
  editValue,
  setEditValue,
  onSaveEdit,
  onNodeDouble,
  onNodeContext,
  onNodeClick,
  onShowComments,
  isDraft,
  featureEnabled,
  updateNode,
  addNode,
  addEdge
}) => {
  const editRef = useRef<HTMLTextAreaElement>(null);
  return (
    <>
      {nodes.map(node => (
        <div
          key={node.id}
          className={`absolute bg-white p-4 rounded-xl shadow-xl border border-gray-200 hover:shadow-2xl transition-all duration-200 ${isDraft ? 'cursor-move' : ''} ${selectedNode?.id===node.id?'ring-2 ring-purple-500':''}`}
          style={{
            left: node.x,
            top: node.y,
            width: node.width || 220,
            height: node.height || 120,
            minWidth: 140,
            minHeight: 70,
            transform: selectedNode?.id===node.id?'scale(1.02)':'scale(1)',
            zIndex: selectedNode?.id===node.id?10:1,
            resize: 'none',
            overflow: 'visible',
          }}
          onClick={e => { console.log('[DEBUG] Node selected', node); onNodeClick(node, e); }}
          onContextMenu={e => onNodeContext(node,e)}
          onDoubleClick={() => onNodeDouble(node)}
          data-coach="add-node"
          draggable={false}
          onMouseDown={isDraft ? (e => {
            if (e.button !== 0) return; // left click only
            const startX = e.clientX;
            const startY = e.clientY;
            const origX = node.x;
            const origY = node.y;
            let moved = false;
            function onMouseMove(ev: MouseEvent) {
              moved = true;
              const dx = ev.clientX - startX;
              const dy = ev.clientY - startY;
              // Update position visually (optimistic)
              // TODO: For smoother UX, use local state or context for immediate feedback
              updateNode(node.id, { x: origX + dx, y: origY + dy });
            }
            function onMouseUp(ev: MouseEvent) {
              window.removeEventListener('mousemove', onMouseMove);
              window.removeEventListener('mouseup', onMouseUp);
              if (moved) {
                const dx = ev.clientX - startX;
                const dy = ev.clientY - startY;
                updateNode(node.id, { x: origX + dx, y: origY + dy });
              }
            }
            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('mouseup', onMouseUp);
          }) : undefined}
        >
        {/* Draggable: onMouseDown starts drag, mousemove updates, mouseup ends drag and persists position. */}
          {/* Edge handle for creating edge */}
          {featureEnabled && isDraft && (
            <div
              className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-purple-400 border-2 border-white shadow cursor-crosshair z-20 flex items-center justify-center"
              title="Drag to create edge"
              draggable={false}
              onMouseDown={() => {/* handled in parent via useEdgeDrag */}}
              style={{ right: -10, top: '50%', transform: 'translateY(-50%)' }}
              data-coach="draw-edge"
            >
              <svg width="12" height="12" viewBox="0 0 12 12">
                <circle cx="6" cy="6" r="5" fill="#a78bfa" stroke="#fff" strokeWidth="2" />
              </svg>
            </div>
          )}
          {/* Comment icon overlay (feature-flagged) */}
          {/* Node action icons: always visible, accessible, and with tooltips/labels */}
{featureEnabled && (
  <div className="absolute flex flex-row gap-1 items-center top-0 left-0 z-30" style={{left: -28, top: -28}}>
    {/* Edit label icon */}
    <button
      className="w-8 h-8 flex items-center justify-center bg-white rounded-full shadow hover:bg-purple-100 focus:outline-none focus:ring-2 focus:ring-purple-400"
      title="Edit label"
      aria-label="Edit node label"
      tabIndex={0}
      onClick={e => { 
        e.stopPropagation();
        // If the node label is 'New node', clear the edit value so the input is empty
        if (node.label === 'New node') setEditValue('');
        else setEditValue(node.label);
        onNodeDouble(node);
      }}
      style={{ fontSize: '1.02rem' }}
    >
      <span aria-hidden="true">✏️</span>
    </button>
    {/* Comment icon */}
    <button
      className="w-8 h-8 flex items-center justify-center bg-white rounded-full shadow hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400"
      title="Add comment"
      aria-label="Add comment to node"
      tabIndex={0}
      onClick={e => { e.stopPropagation(); onShowComments(node.id); }}
      style={{ fontSize: '1.02rem' }}
    >
      <span aria-hidden="true">💬</span>
    </button>
    {/* Delete icon */}
    <button
      className="w-8 h-8 flex items-center justify-center bg-white rounded-full shadow hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-red-400"
      title="Delete node"
      aria-label="Delete node"
      tabIndex={0}
      onClick={e => { e.stopPropagation(); if (typeof onNodeContext === 'function') onNodeContext(node, e as any); }}
      style={{ fontSize: '1.02rem' }}
    >
      <span aria-hidden="true">🗑️</span>
    </button>
  </div>
)}
          {selectedNode?.id===node.id ? (
  <textarea
    ref={editRef}
    onFocus={e => {
      e.target.select();
    }}
    className="w-full border rounded px-2 py-1 focus:ring-1 focus:ring-purple-500 resize-none"
    value={editValue}
    onChange={e => {
      console.log('[DEBUG] textarea onChange value:', e.target.value);
      setEditValue(e.target.value);
    }}
    onBlur={() => { onSaveEdit(); }}
    rows={4}
    style={{ minHeight: 70, minWidth: 80, fontSize: '1.07rem', height: 'auto', overflow: 'hidden' }}
    aria-label="Edit node label"
    onInput={e => {
      const ta = e.target as HTMLTextAreaElement;
      ta.style.height = 'auto';
      ta.style.height = ta.scrollHeight + 'px';
    }}
    autoFocus
  />
) : (
  <>
    {/* Node label and type badge: larger font, no overlap, ellipsis for overflow */}
    <div className="flex flex-col items-start w-full pr-2 h-full" style={{overflowWrap:'break-word', overflowY:'auto'}}>
      <span
        className="font-semibold text-gray-900 text-lg leading-snug w-full"
        style={{lineHeight: '1.2', maxWidth: '100%', wordBreak: 'break-word', whiteSpace: 'pre-line'}}
        title={node.label}
      >
        {node.label}
      </span>
      <span
        className={`mt-1 text-xs px-2 py-0.5 rounded-full select-none ${node.type==='decision'?'bg-blue-100 text-blue-800':node.type==='option'?'bg-green-100 text-green-800':'bg-purple-100 text-purple-800'}`}
        style={{fontWeight: 600, letterSpacing: '0.01em'}}
      >
        {node.type.charAt(0).toUpperCase() + node.type.slice(1)}
      </span>
    </div>
  </>
)}
        </div>
      ))}

      {/* Debug log for selectedNode changes */}
      {selectedNode && <RadialAddMenu node={selectedNode} addNode={addNode} addEdge={addEdge} />}

    </>
  );
});
