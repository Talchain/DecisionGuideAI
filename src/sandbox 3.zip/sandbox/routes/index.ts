export { SandboxRoute } from './SandboxRoute';

export const SANDBOX_ROUTE = '/sandbox';
export const SANDBOX_BOARD_ROUTE = `${SANDBOX_ROUTE}/:boardId?`;
