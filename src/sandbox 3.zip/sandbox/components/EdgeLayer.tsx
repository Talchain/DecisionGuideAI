import React from 'react';
import EdgeLikelihoodEditor from './EdgeLikelihoodEditor';
import type { Node as SandboxNode, Edge } from '../../types/sandbox';

interface EdgeLayerProps {
  nodes?: SandboxNode[];
  edges?: Edge[];
  selectedEdge: Edge | null;
  setSelectedEdge: (edge: Edge | null) => void;
  setSelectedNode: (node: SandboxNode | null) => void;
  toolbarPos: { x: number; y: number };
  setToolbarPos: (pos: { x: number; y: number }) => void;
  onEdgeClick: (edge: Edge, e: React.MouseEvent<SVGPathElement>) => void;
  onEdgeContext: (edge: Edge, e: React.MouseEvent) => void;
  onShowComments: (id: string, opts?: { type?: 'node' | 'edge' }) => void;
  updateEdgeLikelihood?: (id: string, value: number) => void;
}

export const EdgeLayer: React.FC<EdgeLayerProps> = React.memo(({
  nodes = [],
  edges = [],
  selectedEdge,
  setSelectedEdge,
  setSelectedNode,
  toolbarPos,
  setToolbarPos,
  onEdgeClick,
  onEdgeContext,
  onShowComments
}) => {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none">
      <defs>
        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
          <polygon points="0 0, 10 3.5, 0 7" className="fill-purple-500" />
        </marker>
        <marker id="arrowhead-selected" markerWidth="12" markerHeight="8" refX="10" refY="4" orient="auto">
          <polygon points="0 0, 12 4, 0 8" className="fill-purple-700" />
        </marker>
      </defs>
      {(edges || []).map(edge => {
        const src = (nodes || []).find(n => n.id === edge.source);
        const tgt = (nodes || []).find(n => n.id === edge.target);
        if (!src || !tgt) return null;

        // Node dimensions must match NodeLayer constants
        const NODE_WIDTH = 256;
        const NODE_HEIGHT = 130;

        // Helper to get anchor point
        function getAnchor(node: SandboxNode, handle?: 'left' | 'right' | 'bottom') {
          switch (handle) {
            case 'right':
              return { x: node.x + NODE_WIDTH, y: node.y + NODE_HEIGHT/2 };
            case 'left':
              return { x: node.x, y: node.y + NODE_HEIGHT/2 };
            case 'bottom':
              return { x: node.x + NODE_WIDTH/2, y: node.y + NODE_HEIGHT };
            default:
              return { x: node.x + NODE_WIDTH/2, y: node.y + NODE_HEIGHT/2 };
          }
        }
        const sourceAnchor = getAnchor(src, (edge as any).sourceHandle);
        const targetAnchor = getAnchor(tgt, (edge as any).targetHandle);
        const midX = (sourceAnchor.x + targetAnchor.x) / 2;
        const midY = (sourceAnchor.y + targetAnchor.y) / 2;
        const d = `M${sourceAnchor.x},${sourceAnchor.y} Q${midX},${midY} ${targetAnchor.x},${targetAnchor.y}`;
        const sel = selectedEdge?.id === edge.id;

        return (
          <g key={edge.id}>
            {/* Invisible, thick hit area for easy edge selection */}
            <path
              d={d}
              fill="none"
              stroke="transparent"
              strokeWidth={20}
              className="pointer-events-auto"
              onClick={e => onEdgeClick(edge, e)}
              onContextMenu={e => onEdgeContext(edge, e)}
            />
            {/* The actual visible edge line */}
            <path
              d={d}
              fill="none"
              stroke={sel ? '#6d28d9' : '#8b5cf6'}
              strokeWidth={sel ? 3 : 2}
              strokeLinecap="round"
              markerEnd={`url(#${sel ? 'arrowhead-selected' : 'arrowhead'})`}
            />
            {/* Likelihood label */}
            {/* Editable likelihood label for edge */}
<foreignObject
  x={midX - 24}
  y={midY - 24}
  width={48}
  height={32}
  style={{ overflow: 'visible', pointerEvents: 'auto' }}
>
  <EdgeLikelihoodEditor
    edge={edge}
    value={typeof edge.likelihood === 'number' ? edge.likelihood : 50}
    onUpdate={typeof updateEdgeLikelihood === 'function' ? updateEdgeLikelihood : (id, val) => console.log('Update likelihood', id, val)}
  />
</foreignObject>
            {/* Comment icon overlay */}
            {/* Edge comment icon: visually harmonised with node comment button, accessible, pointer events enabled */}
{import.meta.env.VITE_FEATURE_SCENARIO_SANDBOX === 'true' && (
  <foreignObject
    x={midX - 14}
    y={midY + 2}
    width={28}
    height={28}
    style={{
      overflow: 'visible',
      pointerEvents: 'auto',
    }}
  >
    <button
      className="w-7 h-7 flex items-center justify-center bg-white rounded-full shadow border border-gray-200 hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400"
      title="Show comments"
      aria-label="Show comments for edge"
      tabIndex={0}
      style={{
        pointerEvents: 'auto',
        background: 'white',
        border: '1px solid #e5e7eb',
        boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
      }}
      onClick={e => {
        e.stopPropagation();
        onShowComments(edge.id, { type: 'edge' });
      }}
      onKeyDown={e => {
        if ((e.key === 'Enter' || e.key === ' ') && onShowComments) {
          e.preventDefault();
          e.stopPropagation();
          onShowComments(edge.id, { type: 'edge' });
        }
      }}
    >
      <span aria-hidden="true" style={{ fontSize: '1.1rem' }}>💬</span>
    </button>
  </foreignObject>
)}
          </g>
        );
      })}
    </svg>
  );
});

export default EdgeLayer;