import React, { useState, useRef, useEffect } from 'react';
import type { Edge } from '../../types/sandbox';

interface EdgeLikelihoodEditorProps {
  edge: Edge;
  value: number;
  onUpdate: (id: string, value: number) => void;
}

/**
 * Inline editor for edge likelihood (0-100%)
 * - Click or keyboard to edit
 * - Enter/blur saves, Esc cancels
 * - Accessible, visually consistent
 */
export const EdgeLikelihoodEditor: React.FC<EdgeLikelihoodEditorProps> = ({ edge, value, onUpdate }) => {
  const [editing, setEditing] = useState(false);
  const [inputValue, setInputValue] = useState(value);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input when editing starts
  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  // Handle click or keyboard to enter edit mode
  const activateEdit = (e: React.MouseEvent | React.KeyboardEvent) => {
    e.stopPropagation();
    setEditing(true);
    setInputValue(value);
    setError(null);
  };

  // Save new value
  const save = () => {
    if (inputValue < 0 || inputValue > 100 || isNaN(inputValue)) {
      setError('Value must be 0–100');
      return;
    }
    if (inputValue !== value) {
      onUpdate(edge.id, inputValue);
    }
    setEditing(false);
    setError(null);
  };

  // Cancel edit
  const cancel = () => {
    setInputValue(value);
    setEditing(false);
    setError(null);
  };

  // Handle input changes
  const onInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let v = e.target.value.replace(/[^0-9]/g, '');
    let n = Number(v);
    if (v === '') n = 0;
    if (n < 0) n = 0;
    if (n > 100) n = 100;
    setInputValue(n);
    if (n < 0 || n > 100) setError('Value must be 0–100');
    else setError(null);
  };

  // Keyboard handling
  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      save();
    } else if (e.key === 'Escape') {
      cancel();
    }
  };

  if (!editing) {
    return (
      <div
        tabIndex={0}
        role="button"
        aria-label="Edit likelihood"
        className="text-xs font-medium fill-gray-700 cursor-pointer bg-white rounded px-1 focus:outline-none focus:ring-2 focus:ring-blue-400"
        style={{ textAlign: 'center', minWidth: 32, display: 'inline-block', userSelect: 'none' }}
        onClick={activateEdit}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') activateEdit(e);
        }}
      >
        {value}%
      </div>
    );
  }

  return (
    <form
      onSubmit={e => { e.preventDefault(); save(); }}
      style={{ display: 'inline-block', minWidth: 32 }}
      tabIndex={-1}
    >
      <input
        ref={inputRef}
        type="number"
        min={0}
        max={100}
        step={1}
        value={inputValue}
        onChange={onInput}
        onBlur={save}
        onKeyDown={onKeyDown}
        aria-label="Set likelihood (0 to 100 percent)"
        className={`text-xs font-medium px-1 py-0.5 rounded border ${error ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-400`}
        style={{ width: 36, textAlign: 'center' }}
      />
      <span className="text-xs text-gray-500 ml-1">%</span>
      {error && <span className="text-xs text-red-500 ml-2">{error}</span>}
    </form>
  );
};

export default EdgeLikelihoodEditor;
