import React, { RefObject } from 'react';
import { Node as SandboxNode } from '../../types/sandbox';

interface NodeLayerProps {
  nodes: SandboxNode[];
  selectedNode: SandboxNode | null;
  onNodeDouble: (node: SandboxNode) => void;
  onNodeClick: (node: SandboxNode, e: React.MouseEvent<HTMLDivElement>) => void;
  onNodeContext: (node: SandboxNode, e: React.MouseEvent<HTMLDivElement>) => void;
  onShowComments: (id: string) => void;
  editValue: string;
  setEditValue: (val: string) => void;
  isEditing: boolean;
  onSaveEdit: () => void;
  editRef: RefObject<HTMLInputElement>;
}

export const NodeLayer: React.FC<NodeLayerProps> = ({
  nodes,
  selectedNode,
  onNodeDouble,
  onNodeClick,
  onNodeContext,
  editValue,
  setEditValue,
  isEditing,
  onSaveEdit,
  editRef,
}) => (
  <div className="absolute inset-0 w-full h-full pointer-events-none">
    {nodes.map(node => (
      <div
        key={node.id}
        className={`absolute pointer-events-auto bg-white rounded-xl shadow-lg border border-gray-200 px-4 py-3 select-none cursor-pointer
          ${selectedNode?.id === node.id ? 'ring-2 ring-blue-500' : ''}`}
        style={{
          left: node.x,
          top: node.y,
          minWidth: 120,
          minHeight: 48,
          zIndex: 10,
        }}
        onDoubleClick={() => onNodeDouble(node)}
        onClick={e => onNodeClick(node, e)}
        onContextMenu={e => onNodeContext(node, e)}
      >
        {isEditing && selectedNode?.id === node.id ? (
          <input
            ref={editRef}
            className="w-full border-2 border-blue-400 rounded px-2 py-1 text-lg"
            value={editValue}
            autoFocus
            onChange={e => setEditValue(e.target.value)}
            onBlur={onSaveEdit}
            onKeyDown={e => {
              if (e.key === 'Enter') onSaveEdit();
              if (e.key === 'Escape') setEditValue(selectedNode.label || '');
            }}
          />
        ) : (
          <div className="text-lg font-semibold">{node.label}</div>
        )}
      </div>
    ))}
  </div>
);

export default NodeLayer;
