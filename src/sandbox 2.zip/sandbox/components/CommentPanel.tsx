import React, { useRef, useState } from 'react';
import type { Comment } from '../state/useCommentState';

interface CommentPanelProps {
  targetId: string;
  comments: Comment[];
  author: string;
  addComment: (comment: Omit<Comment, 'id' | 'createdAt'>) => void;
  editComment: (id: string, text: string) => void;
  deleteComment: (id: string) => void;
  onClose: () => void;
}

export const CommentPanel: React.FC<CommentPanelProps> = ({ targetId, comments, author, addComment, editComment, deleteComment, onClose }) => {
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<string | undefined>(undefined);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const rootComments = comments.filter(c => !c.parentId);
  const replies = (parentId: string) => comments.filter(c => c.parentId === parentId);

  const handleAdd = () => {
    if (text.trim()) {
      addComment({ targetId, author, text: text.trim(), parentId: replyTo });
      setText('');
      setReplyTo(undefined);
      inputRef.current?.focus();
    }
  };
  const handleEdit = (id: string) => {
    if (editText.trim()) {
      editComment(id, editText.trim());
      setEditingId(null);
      setEditText('');
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (editingId) handleEdit(editingId);
      else handleAdd();
    }
    if (e.key === 'Escape') {
      setEditingId(null);
      setEditText('');
      setReplyTo(undefined);
      onClose();
    }
  };
  return (
    <div className="fixed right-0 top-0 h-full w-80 bg-white shadow-lg z-50 flex flex-col" role="dialog" aria-modal="true" aria-label="Comments">
      <div className="flex items-center justify-between p-3 border-b">
        <span className="font-bold">Comments</span>
        <button aria-label="Close comments" onClick={onClose} className="text-gray-500 hover:text-gray-800">✕</button>
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        {rootComments.length === 0 && <div className="text-gray-400">No comments yet.</div>}
        {rootComments.map(c => (
          <div key={c.id} className="mb-4">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm">{c.author}</span>
              <span className="text-xs text-gray-400">{new Date(c.createdAt).toLocaleString()}</span>
              <button aria-label="Reply" onClick={() => { setReplyTo(c.id); inputRef.current?.focus(); }} className="ml-auto text-xs text-blue-600">Reply</button>
              {c.author === author && <>
                <button aria-label="Edit" onClick={() => { setEditingId(c.id); setEditText(c.text); }} className="text-xs text-green-600 ml-2">Edit</button>
                <button aria-label="Delete" onClick={() => deleteComment(c.id)} className="text-xs text-red-600 ml-1">Delete</button>
              </>}
            </div>
            {editingId === c.id ? (
              <input
                ref={inputRef}
                className="w-full border rounded px-2 py-1 mt-1"
                value={editText}
                onChange={e => setEditText(e.target.value)}
                onKeyDown={handleKeyDown}
                aria-label="Edit comment"
                autoFocus
              />
            ) : (
              <div className="mt-1 text-gray-800 whitespace-pre-line">{c.text}</div>
            )}
            {/* Replies */}
            <div className="ml-4 mt-2">
              {replies(c.id).map(r => (
                <div key={r.id} className="mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs">{r.author}</span>
                    <span className="text-xs text-gray-400">{new Date(r.createdAt).toLocaleString()}</span>
                    {r.author === author && <>
                      <button aria-label="Edit reply" onClick={() => { setEditingId(r.id); setEditText(r.text); }} className="text-xs text-green-600 ml-2">Edit</button>
                      <button aria-label="Delete reply" onClick={() => deleteComment(r.id)} className="text-xs text-red-600 ml-1">Delete</button>
                    </>}
                  </div>
                  {editingId === r.id ? (
                    <input
                      ref={inputRef}
                      className="w-full border rounded px-2 py-1 mt-1"
                      value={editText}
                      onChange={e => setEditText(e.target.value)}
                      onKeyDown={handleKeyDown}
                      aria-label="Edit reply"
                      autoFocus
                    />
                  ) : (
                    <div className="mt-1 text-gray-800 whitespace-pre-line">{r.text}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="p-3 border-t flex flex-col gap-2">
        {replyTo && <div className="text-xs text-gray-600">Replying...</div>}
        <input
          ref={inputRef}
          className="w-full border rounded px-2 py-1"
          value={editingId ? editText : text}
          onChange={e => (editingId ? setEditText(e.target.value) : setText(e.target.value))}
          onKeyDown={handleKeyDown}
          aria-label={editingId ? 'Edit comment' : replyTo ? 'Reply to comment' : 'Add comment'}
          placeholder={editingId ? 'Edit comment...' : replyTo ? 'Reply...' : 'Add a comment...'}
        />
        <div className="flex gap-2">
          {editingId ? (
            <button className="px-3 py-1 rounded bg-green-600 text-white" onClick={() => handleEdit(editingId)} aria-label="Save edit">Save</button>
          ) : (
            <button className="px-3 py-1 rounded bg-blue-600 text-white" onClick={handleAdd} aria-label="Add comment">Add</button>
          )}
          <button className="px-3 py-1 rounded bg-gray-200" onClick={onClose} aria-label="Close">Close</button>
        </div>
      </div>
    </div>
  );
};
