// setupTests.ts - test setup for Scenario Sandbox
import '@testing-library/jest-dom';
